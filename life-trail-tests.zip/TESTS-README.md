# Life Trail test scripts (for Claude's sandbox, not part of the app)

Not meant to be committed to the repo. They were used to check the app in a real headless
Chromium and with fake-indexeddb. Recreate in a fresh sandbox:

1. Put the project in a folder, run `npm install` and `npm run build` (makes `out/`).
2. `scratch/*.ts` are unit tests. Copy the folder into the project root, then run
   `npm i -D fake-indexeddb tsx` (do NOT keep these in the delivered package.json) and
   `npx tsx scratch/formattest.ts` (same for movietest, upgradetest, locktest).
   Some expect a clean database and import from `../src/...`.
3. `browser/*.mjs` drive the built site. In `browser/` run `npm install`, serve the build with
   `npx serve out -l 3300` (start it with setsid nohup from a script), then
   `node tour2.mjs`, `node pwa1.mjs` (offline), `node pwa2.mjs` (app lock),
   `node movies.mjs` (movies with fake TMDB), `node logo.mjs`.
   They save screenshots into `browser/shots/` (create it first).
4. Notes:
   - `lib.mjs` holds the launch settings and the base address (port 3300).
   - `pwa3.mjs` (update flow) edits `src/components/lock/PinField.tsx` at a hard coded path and
     rebuilds, so adjust the path or skip it. The edit it makes is already applied in the app.
   - Scripts print `ok`/`FAIL` lines and finish with `ALL PASSED` or `N FAILED`.
   - Several check texts depend on the app's wording, so update them when the UI text changes.

New in November 2026:
- `scratch/imagetest.ts` checks pictures in backups (file round trip, validation, restore, undo, cleanup, erase). `formattest.ts` now expects backup version 3.
- `browser/editor.mjs` drives the Markdown editor in real Chrome (headings, links, Ctrl+Enter, checkboxes, picture upload and paste, saving, the reader, sidebar collapse). It expects the site on port 3300 and sample pictures at /tmp/bt/big.png and /tmp/bt/small.png, and uses puppeteer-core with a Chrome at /opt/google/chrome/chrome (adjust the path).
- Keep the `scratch/` folder out of the project while running `next build`, it breaks the type check.
- `browser/features.mjs` covers the reading view, Ctrl+Enter save and link opening, the movie poster viewer, movie cards, Insights cards and the How to use page. It seeds its own movies and entries and needs /tmp/bt/poster.png (any small PNG).
- `scratch/showtest.ts` covers shows: the database upgrade from version 3, a film and a show sharing one TMDB id, the backup format with kinds, and restoring copies made before shows existed. `movietest.ts` now mocks the TMDB multi search.
- `browser/shows.mjs` covers searching and logging a show with a mocked TMDB, the Movies/Shows list and filters, the Home page, the sidebar logo and the phone tab bar at 360 px.
