# Life Trail test scripts (for Claude's sandbox, not part of the app)

Not meant to be committed to the repo. They were used to check the app in a real headless
Chromium and with fake-indexeddb. Recreate in a fresh sandbox:

1. Put the project in a folder, run `npm install` and `npm run build` (makes `out/`).
2. `scratch/*.ts` are unit tests. Copy the folder into the project root, then run
   `npm i -D fake-indexeddb tsx` (do NOT keep these in the delivered package.json) and
   `npx tsx scratch/formattest.ts` (same for movietest, upgradetest, locktest).
   Some expect a clean database and import from `../src/...`.
3. `browser/*.mjs` drive the built site. In `browser/` run `npm install`, serve the build with
   `npx serve out -l 3300` (start it with setsid nohup from a script), then
   `node tour2.mjs`, `node pwa1.mjs` (offline), `node pwa2.mjs` (app lock),
   `node movies.mjs` (movies with fake TMDB), `node logo.mjs`.
   They save screenshots into `browser/shots/` (create it first).
4. Notes:
   - `lib.mjs` holds the launch settings and the base address (port 3300).
   - `pwa3.mjs` (update flow) edits `src/components/lock/PinField.tsx` at a hard coded path and
     rebuilds, so adjust the path or skip it. The edit it makes is already applied in the app.
   - Scripts print `ok`/`FAIL` lines and finish with `ALL PASSED` or `N FAILED`.
   - Several check texts depend on the app's wording, so update them when the UI text changes.
