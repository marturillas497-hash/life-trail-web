import "fake-indexeddb/auto";
import { db } from "../src/lib/db";
import { createEntry } from "../src/lib/entries";
import { createSnapshot } from "../src/lib/backup/snapshots";
import { getLockConfig, saveLockConfig } from "../src/lib/lock/store";
import { checkPin, checkRecoveryCode, changePin, disableLock, enableLock, generateRecoveryCode, recoverWithCode, replaceRecoveryCode, setAutoLockSeconds } from "../src/lib/lock/actions";
import { generateRecoveryCode as gen, normalizeRecoveryCode, hashSecret, verifySecret, isValidPin, lockAvailable } from "../src/lib/lock/crypto";
import { eraseEverything } from "../src/lib/lock/erase";
import { getSetting, setSetting } from "../src/lib/backup/store";

let failures = 0;
const check = (label: string, ok: boolean, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };

async function main() {
  check("crypto available in this runtime", lockAvailable());
  check("pin validation", isValidPin("1234") && isValidPin("12345678") && !isValidPin("123") && !isValidPin("123456789") && !isValidPin("12a4") && !isValidPin(""));

  const rec = await hashSecret("secret");
  check("hash verifies the right secret", await verifySecret("secret", rec));
  check("hash rejects a wrong secret", !(await verifySecret("secreT", rec)));
  const rec2 = await hashSecret("secret");
  check("same secret gets a different salt and hash", rec.salt !== rec2.salt && rec.hash !== rec2.hash);

  const code = gen();
  check("recovery code format", /^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test(code) && !/[IO01]/.test(code), code);
  check("recovery code normalization", normalizeRecoveryCode("abcd-efgh ijkl_mnop") === "ABCDEFGHIJKLMNOP");
  check("codes differ between calls", gen() !== gen());

  // --- enable and check
  check("no config initially", (await getLockConfig()) === undefined);
  await enableLock("4821", code);
  const cfg = await getLockConfig();
  check("config saved without the plain PIN", !!cfg && !JSON.stringify(cfg).includes("4821") && !JSON.stringify(cfg).includes(code.replace(/-/g, "")));
  check("default auto-lock is 60 s", cfg?.autoLockSeconds === 60);
  check("correct PIN accepted", (await checkPin("4821")).ok);
  const wrong = await checkPin("0000");
  check("wrong PIN rejected with a message", !wrong.ok && wrong.message.includes("not correct"));

  // --- throttling: 5 wrong tries lock out
  for (let i = 0; i < 3; i++) await checkPin("1111");          // total 4 wrong so far
  const fifth = await checkPin("1111");                          // 5th wrong
  check("5th wrong try triggers a lockout message", !fifth.ok && fifth.message.includes("Too many"), JSON.stringify(fifth));
  const locked = await checkPin("4821");
  check("even the right PIN is refused during lockout", !locked.ok && locked.message.includes("Try again"), JSON.stringify(locked));
  const afterLock = await getLockConfig();
  check("lockout is about 30 s", (afterLock!.lockedUntil - Date.now()) > 25_000 && (afterLock!.lockedUntil - Date.now()) <= 30_000);

  // simulate time passing
  await saveLockConfig({ ...afterLock!, lockedUntil: Date.now() - 1 });
  check("right PIN works after the lockout ends", (await checkPin("4821")).ok);
  check("counter resets after success", (await getLockConfig())!.failedAttempts === 0);

  // second batch doubles to 60 s
  for (let i = 0; i < 5; i++) await checkPin("2222");
  let c2 = await getLockConfig();
  await saveLockConfig({ ...c2!, lockedUntil: 0 });
  for (let i = 0; i < 5; i++) await checkPin("2222");
  // counter reset on success only, so 10 wrong in a row: second batch
  c2 = await getLockConfig();
  const ms = c2!.lockedUntil - Date.now();
  check("second lockout is about 60 s", ms > 55_000 && ms <= 60_000, String(ms));
  await saveLockConfig({ ...c2!, lockedUntil: 0, failedAttempts: 0 });

  // --- change pin
  const bad = await changePin("9999", "5555");
  check("change PIN refuses a wrong current PIN", !bad.ok);
  check("change PIN refuses a short new PIN", !(await changePin("4821", "12")).ok);
  check("change PIN works", (await changePin("4821", "5555")).ok);
  check("old PIN no longer works", !(await checkPin("4821")).ok);
  check("new PIN works", (await checkPin("5555")).ok);

  // --- recovery code
  check("wrong recovery code rejected", !(await checkRecoveryCode("AAAA-BBBB-CCCC-DDDD")).ok);
  const code2 = generateRecoveryCode();
  check("recover with the original code (lower case, spaces)", (await recoverWithCode(code.toLowerCase().replace(/-/g, " "), "7777", code2)).ok);
  check("PIN changed by recovery", (await checkPin("7777")).ok && !(await checkPin("5555")).ok);
  check("old recovery code stops working", !(await checkRecoveryCode(code)).ok);
  check("new recovery code works", (await checkRecoveryCode(code2)).ok);
  await saveLockConfig({ ...(await getLockConfig())!, failedAttempts: 0, lockedUntil: 0 });

  // --- replace recovery code
  const code3 = generateRecoveryCode();
  check("replace recovery code needs the PIN", !(await replaceRecoveryCode("0000", code3)).ok);
  check("replace recovery code works", (await replaceRecoveryCode("7777", code3)).ok && (await checkRecoveryCode(code3)).ok);

  // --- auto lock setting
  await setAutoLockSeconds(-1);
  check("auto-lock setting saved", (await getLockConfig())!.autoLockSeconds === -1);

  // --- disable
  check("disable needs the right PIN", !(await disableLock("0000")).ok && (await getLockConfig()) !== undefined);
  await saveLockConfig({ ...(await getLockConfig())!, failedAttempts: 0, lockedUntil: 0 });
  check("disable works", (await disableLock("7777")).ok && (await getLockConfig()) === undefined);

  // --- erase everything
  await enableLock("1234", gen());
  const tags = await db.tags.orderBy("id").toArray();
  await createEntry({ title: "x", body: "y", tagIds: [tags[0].id] }, "2026-10-01");
  await createSnapshot("manual");
  await setSetting("lastFileBackupAt", 123);
  await eraseEverything();
  check("erase clears entries", (await db.entries.count()) === 0);
  check("erase restores the 16 default tags", (await db.tags.count()) === 16);
  check("erase clears the lock and settings", (await getLockConfig()) === undefined && (await getSetting("lastFileBackupAt")) === undefined);

  console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}
main().catch((e) => { console.error("ERROR", e); process.exit(1); });
