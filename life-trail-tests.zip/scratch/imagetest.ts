import "fake-indexeddb/auto";
import { db } from "../src/lib/db";
import { createEntry } from "../src/lib/entries";
import { readCurrentData, replaceJournal, createSnapshot, restoreSnapshot, runDailySnapshot } from "../src/lib/backup/snapshots";
import { backupDb } from "../src/lib/backup/store";
import { buildBackupFile, serializeBackup, parseBackup, hashData, summarize, bytesToBase64, base64ToBytes } from "../src/lib/backup/format";
import { removeUnusedImages, readImageStats } from "../src/lib/images";
import { eraseEverything } from "../src/lib/lock/erase";

let failures = 0;
const check = (label: string, ok: boolean, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };
const throwsMsg = (label: string, fn: () => unknown, contains: string) => {
  try { fn(); check(label, false, "did not throw"); } catch (e) { check(label, (e as Error).message.includes(contains), (e as Error).message); }
};

const bytes = (...values: number[]) => new Uint8Array(values).buffer;
const add = (name: string, data: ArrayBuffer) =>
  db.images.add({ name, type: "image/webp", width: 10, height: 20, data, createdAt: 111 });

async function main() {
  const tagId = (await db.tags.toArray())[0].id;

  // ---------- base64 ----------
  const raw = new Uint8Array(70000).map((_, i) => (i * 7) % 256).buffer;
  check("base64 round trip, large", Buffer.compare(Buffer.from(base64ToBytes(bytesToBase64(raw))), Buffer.from(raw)) === 0);

  // ---------- storage ----------
  const id1 = await add("a.webp", bytes(1, 2, 3, 4));
  const id2 = await add("b.webp", bytes(9, 8, 7));
  const stored = await db.images.get(id1);
  check("bytes survive IndexedDB", stored !== undefined && new Uint8Array(stored.data).join() === "1,2,3,4");
  await createEntry({ title: "x", body: `hello ![a](image:${id1}) world`, tagIds: [tagId] }, "2026-11-01");

  // ---------- reading ----------
  const plain = await readCurrentData();
  check("default read leaves pictures out", plain.images === undefined);
  const full = await readCurrentData({ withImages: true });
  check("withImages includes both pictures", full.images?.length === 2 && full.images[0].data === bytesToBase64(bytes(1, 2, 3, 4)));

  // ---------- hash ----------
  const h0 = hashData(plain);
  check("empty images list does not change the hash", hashData({ ...plain, images: [] }) === h0);
  check("pictures change the hash", hashData(full) !== h0);

  // ---------- file round trip ----------
  const text = serializeBackup(buildBackupFile(full));
  const parsed = parseBackup(text);
  check("file round trip keeps pictures", parsed.images?.length === 2 && parsed.images[1].name === "b.webp");
  check("summary counts pictures", summarize(parsed).imageCount === 2);
  const v2 = parseBackup(JSON.stringify({ ...JSON.parse(text), version: 2, images: undefined }));
  check("a version 2 file loads with no pictures", v2.images?.length === 0);

  // ---------- validation ----------
  const withImage = (patch: object) => JSON.stringify({ ...JSON.parse(text), images: [{ ...JSON.parse(text).images[0], ...patch }] });
  throwsMsg("bad base64 refused", () => parseBackup(withImage({ data: "not base64!!" })), "bad data");
  throwsMsg("svg refused", () => parseBackup(withImage({ type: "image/svg+xml" })), "unsupported type");
  throwsMsg("bad dimensions refused", () => parseBackup(withImage({ width: 0 })), "dimensions");
  throwsMsg("duplicate ids refused", () => parseBackup(JSON.stringify({ ...JSON.parse(text), images: [JSON.parse(text).images[0], JSON.parse(text).images[0]] })), "duplicate picture ids");
  throwsMsg("pictures must be a list", () => parseBackup(JSON.stringify({ ...JSON.parse(text), images: "x" })), "not a list");

  // ---------- restore from a snapshot without pictures keeps them ----------
  await db.images.clear();
  const keep = await add("keep.webp", bytes(5, 5, 5));
  await replaceJournal(plain);
  const afterSnapshotRestore = await db.images.toArray();
  check("restoring data without pictures leaves pictures alone", afterSnapshotRestore.length === 1 && afterSnapshotRestore[0].id === keep);

  // ---------- restore from a file replaces pictures ----------
  await replaceJournal(parsed);
  const replaced = await db.images.toArray();
  check("restoring a file replaces pictures", replaced.length === 2 && replaced.map((r) => r.id).join() === `${id1},${id2}`);
  check("restored bytes match", new Uint8Array(replaced[0].data).join() === "1,2,3,4");

  // ---------- undo: pre-restore snapshot holds pictures ----------
  const pre = (await backupDb.snapshots.where("kind").equals("pre-restore").sortBy("createdAt")).pop()!;
  check("pre-restore snapshot includes the old pictures", pre.data.images?.length === 1 && pre.data.images[0].id === keep);
  await restoreSnapshot(pre.id);
  const undone = await db.images.toArray();
  check("undo brings the old picture back", undone.length === 1 && undone[0].id === keep);

  // ---------- daily snapshots stay small ----------
  await runDailySnapshot();
  const auto = await backupDb.snapshots.where("kind").equals("auto").first();
  check("daily snapshots carry no pictures", auto !== undefined && auto.data.images === undefined);
  const manual = await createSnapshot("manual");
  check("manual snapshots carry no pictures", manual !== null && manual.data.images === undefined);

  // ---------- cleanup of unused pictures ----------
  await replaceJournal(parsed);
  const stats = await readImageStats();
  check("stats see one unused picture", stats.count === 2 && stats.unusedCount === 1 && stats.unusedBytes === 3);
  check("removeUnusedImages removes only the unused one", (await removeUnusedImages()) === 1 && (await db.images.count()) === 1 && (await db.images.get(id1)) !== undefined);

  // ---------- erase ----------
  await eraseEverything();
  check("erase clears pictures", (await db.images.count()) === 0);

  console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}
main().catch((e) => { console.error(e); process.exit(1); });
