import "fake-indexeddb/auto";
import Dexie from "dexie";

let failures = 0;
const check = (label: string, ok: boolean, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };

async function main() {
  // 1. Build a real version 1 database exactly like the app had before movies.
  const old = new Dexie("life-trail");
  old.version(1).stores({ tags: "++id, name, isArchived", entries: "++id, date, *tagIds, createdAt" });
  await old.open();
  await old.table("tags").bulkAdd([
    { name: "Happy", emoji: "😊", color: "#FACC15", isArchived: 0, createdAt: 1 },
    { name: "Sad", emoji: "😢", color: "#3B82F6", isArchived: 0, createdAt: 1 },
  ]);
  await old.table("entries").bulkAdd([
    { date: "2026-10-01", title: "Old one", body: "from v1", tagIds: [1], createdAt: 10, updatedAt: 10 },
    { date: "2026-10-02", title: "Old two", body: "also v1", tagIds: [1, 2], createdAt: 20, updatedAt: 20 },
  ]);
  old.close();
  console.log("created a version 1 database with 2 entries");

  // 2. Now load the app's current database code and run the automatic backups.
  const { db } = await import("../src/lib/db");
  const { runAutomaticBackups } = await import("../src/lib/backup/runner");
  const { backupDb } = await import("../src/lib/backup/store");

  await db.open();
  check("upgrade kept the old entries", (await db.entries.count()) === 2);
  check("upgrade kept the old tags (no re-seeding)", (await db.tags.count()) === 2);
  check("movie tables exist and are empty", (await db.movies.count()) === 0 && (await db.movieLogs.count()) === 0);

  await runAutomaticBackups();
  const snaps = await backupDb.snapshots.toArray();
  const pre = snaps.filter((s) => s.kind === "pre-upgrade");
  check("a 'before an app update' snapshot was saved", pre.length === 1, JSON.stringify(snaps.map((s) => s.kind)));
  check("it holds the original 2 entries", pre[0]?.entryCount === 2 && pre[0]?.data.entries.length === 2);
  check("it holds the original tags", pre[0]?.tagCount === 2);
  check("it is stored with empty movie lists", pre[0]?.data.movies.length === 0 && pre[0]?.data.movieLogs.length === 0);
  check("a normal daily snapshot was also made", snaps.some((s) => s.kind === "auto"));

  await runAutomaticBackups();
  check("running again does not duplicate the upgrade snapshot", (await backupDb.snapshots.where("kind").equals("pre-upgrade").count()) === 1);

  // 3. Restoring that snapshot puts the old data back and tolerates missing movie lists
  const { restoreSnapshot } = await import("../src/lib/backup/snapshots");
  await db.entries.clear();
  await restoreSnapshot(pre[0].id);
  check("restoring the upgrade snapshot brings the entries back", (await db.entries.count()) === 2);

  // 4. A snapshot saved by the OLD code has no movie lists at all
  const legacy = { ...pre[0].data } as any; delete legacy.movies; delete legacy.movieLogs;
  const id = await backupDb.snapshots.add({ createdAt: Date.now(), day: "2026-01-01", kind: "manual", entryCount: 2, tagCount: 2, hash: "x", data: legacy });
  await db.movies.add({ tmdbId: null, title: "Temp", year: null, overview: "", posterPath: null, posterData: null, createdAt: 1, fetchedAt: null });
  await restoreSnapshot(id);
  check("legacy snapshot without movie lists restores cleanly", (await db.entries.count()) === 2 && (await db.movies.count()) === 0);

  console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}
main().catch((e) => { console.error("ERROR", e); process.exit(1); });
