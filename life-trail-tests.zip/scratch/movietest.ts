import "fake-indexeddb/auto";
import { db } from "../src/lib/db";
import { logMovie, updateMovieLog, deleteMovieLog } from "../src/lib/movies";
import { parseCredential, searchTitles, checkCredential, fetchPosterData, posterUrl, TmdbError } from "../src/lib/tmdb";
import { todayKey } from "../src/lib/dates";
import { createEntry } from "../src/lib/entries";
import { runDailySnapshot, readCurrentData, replaceJournal } from "../src/lib/backup/snapshots";
import { backupDb } from "../src/lib/backup/store";
import { buildBackupFile, serializeBackup, parseBackup } from "../src/lib/backup/format";

let failures = 0;
const check = (label: string, ok: boolean, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };
const rejects = async (label: string, fn: () => Promise<unknown>, contains: string) => {
  try { await fn(); check(label, false, "did not throw"); } catch (e) { check(label, (e as Error).message.includes(contains), (e as Error).message); }
};

async function main() {
// ---------- credentials ----------
const key32 = "0123456789abcdef0123456789ABCDEF";
const token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJ4In0.c2lnbmF0dXJl";
check("v3 key recognised", parseCredential(key32)?.kind === "key");
check("v4 token recognised", parseCredential(`  ${token}\n`)?.kind === "token");
check("garbage refused", parseCredential("hello") === null && parseCredential("") === null && parseCredential(undefined) === null);
check("short key refused", parseCredential("abc123") === null);

// ---------- fetch mock ----------
const calls: { url: string; headers: Record<string, string> }[] = [];
let respond: (url: URL) => Response | Promise<Response> = () => new Response("{}");
(globalThis as any).fetch = async (input: URL | string, init?: RequestInit) => {
  const url = new URL(String(input));
  calls.push({ url: url.toString(), headers: (init?.headers ?? {}) as Record<string, string> });
  return respond(url);
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

respond = () => json({ results: [
  { id: 27205, media_type: "movie", title: "Inception", release_date: "2010-07-15", overview: "Dreams.", poster_path: "/abc.jpg" },
  { id: 1, media_type: "movie", title: "No date", release_date: "", overview: null, poster_path: null },
  { id: "bad", media_type: "movie", title: "Skipped" },
  { id: 2, media_type: "movie", title: "   " },
  { id: 84958, media_type: "tv", name: "Loki", first_air_date: "2021-06-09", overview: "God of mischief.", poster_path: "/loki.jpg" },
  { id: 3, media_type: "person", name: "Someone" },
  { id: 4, media_type: "tv", name: "" },
] });
const found = await searchTitles({ kind: "token", value: token }, "inception");
check("search keeps only usable movies and shows", found.length === 3, JSON.stringify(found.map((f) => f.title)));
check("shows are found and marked as shows", found[2].kind === "tv" && found[2].title === "Loki" && found[2].year === 2021 && found[0].kind === "movie");
check("year parsed from the release date", found[0].year === 2010 && found[1].year === null);
check("missing overview and poster become safe defaults", found[1].overview === "" && found[1].posterPath === null);
const c1 = calls[0];
check("token goes in the Authorization header", c1.headers.Authorization === `Bearer ${token}`);
check("token is NOT put in the URL", !c1.url.includes(token) && !c1.url.includes("api_key"));
check("search URL has no slash before the query", c1.url.startsWith("https://api.themoviedb.org/3/search/multi?"), c1.url);
check("adult results excluded", c1.url.includes("include_adult=false"));
await searchTitles({ kind: "key", value: key32 }, "x y");
const c2 = calls[1];
check("v3 key goes in the api_key parameter", new URL(c2.url).searchParams.get("api_key") === key32 && !c2.headers.Authorization);
check("search text is URL-encoded", new URL(c2.url).searchParams.get("query") === "x y");

respond = () => json({}, 401);
await rejects("401 gives a key message without leaking the key", () => searchTitles({ kind: "key", value: key32 }, "x"), "did not accept");
try { await searchTitles({ kind: "key", value: key32 }, "x"); } catch (e) { check("error text never contains the key", !String((e as Error).message).includes(key32) && e instanceof TmdbError); }
respond = () => json({}, 429);
await rejects("429 gives a wait message", () => searchTitles({ kind: "key", value: key32 }, "x"), "too many");
respond = () => json({}, 500);
await rejects("500 gives a generic message", () => searchTitles({ kind: "key", value: key32 }, "x"), "(500)");
respond = () => { throw new TypeError("Failed to fetch"); };
await rejects("network failure gives an offline message", () => searchTitles({ kind: "key", value: key32 }, "x"), "Could not reach TMDB");
respond = () => json({ images: {} });
await checkCredential({ kind: "key", value: key32 });
check("check call uses /configuration", calls[calls.length - 1].url.includes("/3/configuration?"));

// poster copy
respond = () => new Response(new Blob([new Uint8Array(1200)], { type: "image/jpeg" }), { status: 200 });
const data = await fetchPosterData("/abc.jpg");
check("poster copied as a data URL", !!data && data.startsWith("data:image/jpeg;base64,"));
check("poster URL built from the path", posterUrl("/abc.jpg") === "https://image.tmdb.org/t/p/w185/abc.jpg");
respond = () => new Response(new Blob([new Uint8Array(500_000)], { type: "image/jpeg" }));
check("oversized poster is skipped", (await fetchPosterData("/big.jpg")) === null);
respond = () => new Response("<html>", { headers: { "content-type": "text/html" } });
check("non-image response is skipped", (await fetchPosterData("/x.jpg")) === null);
respond = () => json({}, 404);
check("404 poster is skipped", (await fetchPosterData("/x.jpg")) === null);
respond = () => { throw new TypeError("offline"); };
check("offline poster fetch returns null, not an error", (await fetchPosterData("/x.jpg")) === null);
check("no poster path returns null", (await fetchPosterData(null)) === null);

// ---------- logging ----------
const inception = { kind: "movie" as const, tmdbId: 27205, title: "Inception", year: 2010, overview: "Dreams.", posterPath: "/abc.jpg", posterData: "data:image/jpeg;base64,AAAA" };
const today = todayKey();
const log1 = await logMovie({ movie: inception }, { rating: 4.5, opinion: "  Mind bending  ", watchedDate: today });
check("log created", (await db.movieLogs.count()) === 1 && (await db.movies.count()) === 1);
const stored = await db.movieLogs.get(log1);
check("opinion is trimmed and rating kept", stored?.opinion === "Mind bending" && stored?.rating === 4.5);
check("TMDB movie gets a fetchedAt time", (await db.movies.toArray())[0].fetchedAt !== null);

const log2 = await logMovie({ movie: inception }, { rating: 5, opinion: "Rewatch", watchedDate: today });
check("same TMDB movie is reused, not duplicated", (await db.movies.count()) === 1 && (await db.movieLogs.count()) === 2);
const movieId = (await db.movies.toArray())[0].id;
const log3 = await logMovie({ movieId }, { rating: 3, opinion: "", watchedDate: "2026-01-02" });
check("log by existing movie id works", (await db.movieLogs.count()) === 3);

const manualA = await logMovie({ movie: { kind: "movie" as const, tmdbId: null, title: "Home Video", year: null, overview: "", posterPath: null, posterData: null } }, { rating: 2.5, opinion: "", watchedDate: today });
const manualB = await logMovie({ movie: { kind: "movie" as const, tmdbId: null, title: "Home Video", year: null, overview: "", posterPath: null, posterData: null } }, { rating: 3, opinion: "", watchedDate: today });
check("two manual movies with the same title stay separate", (await db.movies.count()) === 3, String(await db.movies.count()));
check("manual movie has no fetchedAt", (await db.movies.toArray()).filter((m) => m.tmdbId === null).every((m) => m.fetchedAt === null));
void manualA; void manualB;

await rejects("rating 0 refused", () => logMovie({ movieId }, { rating: 0, opinion: "", watchedDate: today }), "rating");
await rejects("rating 4.3 refused", () => logMovie({ movieId }, { rating: 4.3, opinion: "", watchedDate: today }), "rating");
await rejects("rating 5.5 refused", () => logMovie({ movieId }, { rating: 5.5, opinion: "", watchedDate: today }), "rating");
await rejects("future date refused", () => logMovie({ movieId }, { rating: 4, opinion: "", watchedDate: "2999-01-01" }), "future");
await rejects("impossible date refused", () => logMovie({ movieId }, { rating: 4, opinion: "", watchedDate: "2026-02-31" }), "valid date");
await rejects("empty title refused", () => logMovie({ movie: { ...inception, tmdbId: null, title: "  " } }, { rating: 4, opinion: "", watchedDate: today }), "title");
await rejects("unknown movie id refused", () => logMovie({ movieId: 999 }, { rating: 4, opinion: "", watchedDate: today }), "no longer exists");
check("refused logs left nothing behind", (await db.movieLogs.count()) === 5);

await updateMovieLog(log1, { rating: 2, opinion: "Changed my mind", watchedDate: "2026-02-02" });
const upd = await db.movieLogs.get(log1);
check("update changes the log", upd?.rating === 2 && upd?.opinion === "Changed my mind" && upd?.watchedDate === "2026-02-02" && upd!.updatedAt >= upd!.createdAt);
await rejects("update validates too", () => updateMovieLog(log1, { rating: 9, opinion: "", watchedDate: today }), "rating");

// ---------- deleting ----------
await deleteMovieLog(log1);
check("deleting one of several logs keeps the movie", (await db.movies.get(movieId)) !== undefined);
await deleteMovieLog(log3);
await deleteMovieLog(log2);
check("deleting the last log removes the movie too", (await db.movies.get(movieId)) === undefined);
await deleteMovieLog(12345);
check("deleting a missing log does nothing", true);

// ---------- backups carry movies ----------
await logMovie({ movie: inception }, { rating: 4, opinion: "back again", watchedDate: today });
const tags = await db.tags.orderBy("id").toArray();
await createEntry({ title: "e", body: "b", tagIds: [tags[0].id] });
await runDailySnapshot();
const snap = (await backupDb.snapshots.toArray()).find((s) => s.kind === "auto")!;
check("daily snapshot includes the movie logs", snap.movieLogCount === snap.data.movieLogs.length && snap.data.movieLogs.length >= 1 && snap.data.movies.length >= 1);
const before = await readCurrentData();
const file = parseBackup(serializeBackup(buildBackupFile(before)));
await db.movieLogs.clear(); await db.movies.clear();
await replaceJournal(file);
const after = await readCurrentData();
check("restore from file brings movies and logs back", after.movies.length === before.movies.length && after.movieLogs.length === before.movieLogs.length);
check("poster data survives the round trip", after.movies.some((m) => m.posterData === "data:image/jpeg;base64,AAAA"));



  // a journal with only movies must still be protected
  await db.entries.clear();
  await backupDb.snapshots.clear();
  await runDailySnapshot();
  const movieOnly = await backupDb.snapshots.toArray();
  check("movies-only journal still gets a daily snapshot", movieOnly.length === 1 && (movieOnly[0].movieLogCount ?? 0) > 0 && movieOnly[0].entryCount === 0, JSON.stringify(movieOnly.map((m) => m.entryCount)));
  await db.movieLogs.clear(); await db.movies.clear();
  await backupDb.snapshots.clear();
  await runDailySnapshot();
  check("a truly empty journal still gets no snapshot", (await backupDb.snapshots.count()) === 0);

  console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}
main().catch((e) => { console.error('ERROR', e); process.exit(1); });
