import { buildBackupFile, serializeBackup, parseBackup, hashData, summarize, BACKUP_VERSION } from "../src/lib/backup/format";

let failures = 0;
const check = (label: string, ok: boolean, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };
const throwsMsg = (label: string, fn: () => unknown, contains: string) => {
  try { fn(); check(label, false, "did not throw"); } catch (e) { const m = (e as Error).message; check(label, m.includes(contains), m); }
};

const data = {
  tags: [{ id: 1, name: "Happy", emoji: "😊", color: "#FACC15", isArchived: 0 as const, createdAt: 1 }],
  entries: [{ id: 1, date: "2026-10-01", title: "t", body: "b", tagIds: [1], createdAt: 2, updatedAt: 2 }],
  movies: [
    { id: 1, tmdbId: 27205, title: "Inception", year: 2010, overview: "Dreams.", posterPath: "/x.jpg", posterData: "data:image/jpeg;base64,AAAA", createdAt: 3, fetchedAt: 3 },
    { id: 2, tmdbId: null, title: "Home video", year: null, overview: "", posterPath: null, posterData: null, createdAt: 4, fetchedAt: null },
  ],
  movieLogs: [
    { id: 1, movieId: 1, rating: 4.5, opinion: "Great", watchedDate: "2026-10-02", createdAt: 5, updatedAt: 5 },
    { id: 2, movieId: 1, rating: 5, opinion: "Rewatch", watchedDate: "2026-10-09", createdAt: 6, updatedAt: 6 },
  ],
};
const file = buildBackupFile(data, 1700000000000);
const text = serializeBackup(file);

check("backup version is 2", BACKUP_VERSION === 2 && file.version === 2);
const parsed = parseBackup(text);
check("v2 round trip keeps movies and logs", parsed.movies.length === 2 && parsed.movieLogs.length === 2);
check("v2 round trip keeps the poster data", parsed.movies[0].posterData === "data:image/jpeg;base64,AAAA");
check("v2 round trip keeps a manual movie", parsed.movies[1].tmdbId === null);
check("hash stable across a round trip", hashData(parsed) === hashData(data));
check("hash changes when a rating changes", hashData({ ...data, movieLogs: [{ ...data.movieLogs[0], rating: 3 }, data.movieLogs[1]] }) !== hashData(data));
const s = summarize(data);
check("summary counts movies and logs", s.movieCount === 2 && s.movieLogCount === 2);

// a version 1 file from before movies existed
const v1 = JSON.stringify({ app: "life-trail", version: 1, exportedAt: 5, tags: data.tags, entries: data.entries });
const parsedV1 = parseBackup(v1);
check("version 1 file still imports, with no movies", parsedV1.entries.length === 1 && parsedV1.movies.length === 0 && parsedV1.movieLogs.length === 0);
throwsMsg("a version 2 file must carry its movie lists", () => parseBackup(JSON.stringify({ app: "life-trail", version: 2, exportedAt: 5, tags: [], entries: [] })), "missing its movies");
throwsMsg("a version 3 file is refused", () => parseBackup(JSON.stringify({ ...file, version: 3 })), "newer version");

const bad = (mutate: (f: any) => void, contains: string, label: string) => { const c = JSON.parse(text); mutate(c); throwsMsg(label, () => parseBackup(JSON.stringify(c)), contains); };
bad((f) => { f.movieLogs[0].rating = 4.3; }, "bad rating", "rating must be a half step");
bad((f) => { f.movieLogs[0].rating = 0; }, "bad rating", "rating of 0 refused");
bad((f) => { f.movieLogs[0].rating = 5.5; }, "bad rating", "rating above 5 refused");
bad((f) => { f.movieLogs[0].movieId = 99; }, "not in the file", "log pointing to a missing movie");
bad((f) => { f.movieLogs[1].id = f.movieLogs[0].id; }, "duplicate movie log ids", "duplicate log ids");
bad((f) => { f.movies[1].id = f.movies[0].id; }, "duplicate movie ids", "duplicate movie ids");
bad((f) => { f.movies[0].title = " "; }, "no title", "empty title");
bad((f) => { f.movies[0].year = "2010"; }, "bad year", "year must be a number");
bad((f) => { f.movieLogs[0].watchedDate = "2026-13-01"; }, "bad date", "bad watched date");
bad((f) => { f.movies[0].posterData = 5; }, "bad poster", "poster data must be text");

console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
