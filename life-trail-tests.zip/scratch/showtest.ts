import "fake-indexeddb/auto";
import Dexie from "dexie";

let failures = 0;
const check = (label: string, ok: boolean, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };
const rejects = async (label: string, fn: () => Promise<unknown>, contains: string) => {
  try { await fn(); check(label, false, "did not throw"); } catch (e) { check(label, (e as Error).message.includes(contains), (e as Error).message); }
};

async function main() {
  // A journal saved by version 3 of the app: one movie with no kind.
  const legacy = new Dexie("life-trail");
  legacy.version(1).stores({ tags: "++id, name, isArchived", entries: "++id, date, *tagIds, createdAt" });
  legacy.version(2).stores({ movies: "++id, &tmdbId, title", movieLogs: "++id, movieId, watchedDate, createdAt" });
  legacy.version(3).stores({ images: "++id, createdAt" });
  await legacy.open();
  await legacy.table("movies").add({ tmdbId: 5, title: "Old Film", year: 2000, overview: "", posterPath: null, posterData: null, createdAt: 1, fetchedAt: 1 });
  await legacy.table("movies").add({ tmdbId: null, title: "Home Video", year: null, overview: "", posterPath: null, posterData: null, createdAt: 2, fetchedAt: null });
  await legacy.table("movieLogs").add({ movieId: 1, rating: 4, opinion: "", watchedDate: "2026-01-01", createdAt: 1, updatedAt: 1 });
  legacy.close();

  const { db } = await import("../src/lib/db");
  const { logMovie, logTmdbMovie } = await import("../src/lib/movies");
  const { readCurrentData, replaceJournal } = await import("../src/lib/backup/snapshots");
  const { buildBackupFile, serializeBackup, parseBackup, hashData } = await import("../src/lib/backup/format");

  await db.open();
  const old = await db.movies.toArray();
  check("upgrade marks every old movie as a film", old.length === 2 && old.every((m) => m.kind === "movie"), JSON.stringify(old.map((m) => m.kind)));
  check("old rows are found through the new index", (await db.movies.where("[kind+tmdbId]").equals(["movie", 5]).first())?.title === "Old Film");

  // The same TMDB number can be a film and a show.
  const loki = { kind: "tv" as const, tmdbId: 5, title: "Loki", year: 2021, overview: "", posterPath: null, posterData: "data:image/png;base64,AAAA" };
  const lokiLog = await logMovie({ movie: loki }, { rating: 4.5, opinion: "great", watchedDate: "2026-02-02" });
  check("a show can share a TMDB id with a film", (await db.movies.count()) === 3 && (await db.movieLogs.get(lokiLog)) !== undefined);
  const again = await logMovie({ movie: loki }, { rating: 4, opinion: "again", watchedDate: "2026-02-03" });
  check("logging the same show again reuses it", (await db.movies.count()) === 3 && (await db.movieLogs.get(again))?.movieId === (await db.movieLogs.get(lokiLog))?.movieId);

  const sameFilm = await logMovie({ movie: { ...loki, kind: "movie", title: "Old Film" } }, { rating: 3, opinion: "", watchedDate: "2026-02-04" });
  check("logging the film again reuses the film, not the show", (await db.movieLogs.get(sameFilm))?.movieId === 1);

  // logTmdbMovie keeps kinds apart too
  const viaTmdb = await logTmdbMovie({ ...loki, posterPath: null }, { rating: 5, opinion: "", watchedDate: "2026-02-05" });
  check("logTmdbMovie finds the show by kind and id", (await db.movieLogs.get(viaTmdb))?.movieId === (await db.movieLogs.get(lokiLog))?.movieId);
  await rejects("empty show title gives a show message", () => logMovie({ movie: { ...loki, tmdbId: null, title: " " } }, { rating: 3, opinion: "", watchedDate: "2026-02-05" }), "show's title");

  // backup
  const data = await readCurrentData();
  check("read data carries kinds", data.movies.filter((m) => m.kind === "tv").length === 1);
  const text = serializeBackup(buildBackupFile(data));
  const parsed = parseBackup(text);
  check("file round trip keeps the kind", parsed.movies.find((m) => m.title === "Loki")?.kind === "tv" && parsed.movies.find((m) => m.title === "Old Film")?.kind === "movie");
  check("sharing an id across kinds is accepted", parsed.movies.filter((m) => m.tmdbId === 5).length === 2);

  const raw = JSON.parse(text);
  const noKind = { ...raw, version: 3, movies: raw.movies.map((m: Record<string, unknown>) => { const { kind, ...rest } = m; void kind; return m.title === "Loki" ? { ...rest, tmdbId: 99 } : rest; }) };
  check("a version 3 file (no kinds) loads as films", parseBackup(JSON.stringify(noKind)).movies.every((m) => m.kind === "movie"));
  const badKind = { ...raw, movies: raw.movies.map((m: Record<string, unknown>, i: number) => (i === 0 ? { ...m, kind: "radio" } : m)) };
  try { parseBackup(JSON.stringify(badKind)); check("unknown kind refused", false); } catch (e) { check("unknown kind refused", (e as Error).message.includes("bad type"), (e as Error).message); }
  const dup = { ...raw, movies: raw.movies.map((m: Record<string, unknown>) => (m.title === "Loki" ? { ...m, kind: "movie" } : m)) };
  try { parseBackup(JSON.stringify(dup)); check("two films with one TMDB id refused", false); } catch (e) { check("two films with one TMDB id refused", (e as Error).message.includes("duplicate TMDB ids"), (e as Error).message); }

  // hashing and restoring
  const filmsOnly = { ...data, movies: data.movies.filter((m) => m.kind === "movie") };
  check("a show changes the fingerprint", hashData(filmsOnly) !== hashData(data));
  check("kind movie does not change an old fingerprint", hashData(filmsOnly) === hashData({ ...filmsOnly, movies: filmsOnly.movies.map((m) => ({ ...m, kind: undefined as never })) }));
  const legacySnapshot = { ...data, movies: data.movies.map((m) => { const { kind, ...rest } = m; void kind; return (m.title === "Loki" ? { ...rest, tmdbId: 99 } : rest) as never; }) };
  await replaceJournal(legacySnapshot);
  check("restoring a copy without kinds stores films", (await db.movies.toArray()).every((m) => m.kind === "movie"));
  await replaceJournal(parsed);
  check("restoring a file brings the show back", (await db.movies.where("kind").equals("tv").count().catch(() => -1)) !== 0 && (await db.movies.toArray()).some((m) => m.kind === "tv"));

  console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}
main().catch((e) => { console.error(e); process.exit(1); });
