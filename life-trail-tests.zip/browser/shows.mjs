import puppeteer from "puppeteer-core";
import fs from "node:fs";

const BASE = "http://localhost:3300";
let failures = 0;
const check = (label, ok, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : String(extra)); if (!ok) failures++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await puppeteer.launch({ executablePath: "/opt/google/chrome/chrome", headless: "new", args: ["--no-sandbox", "--disable-gpu"] });
const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 900 });
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => { if (m.type() === "error" && !/net::ERR|Failed to load resource|icon from the Manifest/.test(m.text())) errors.push(m.text()); });

// Pretend to be TMDB.
const requests = [];
await page.setRequestInterception(true);
page.on("request", (req) => {
  const url = req.url();
  if (url.startsWith("https://api.themoviedb.org/")) {
    requests.push(url);
    const results = [
      { id: 100, media_type: "movie", title: "Loki: The Movie", release_date: "2010-01-01", overview: "A film.", poster_path: "/a.jpg" },
      { id: 84958, media_type: "tv", name: "Loki", first_air_date: "2021-06-09", overview: "The god of mischief.", poster_path: "/loki.jpg" },
      { id: 55, media_type: "person", name: "Loki Person" },
    ];
    return req.respond({ status: 200, contentType: "application/json", headers: { "access-control-allow-origin": "*" }, body: JSON.stringify({ results }) });
  }
  if (url.startsWith("https://image.tmdb.org/")) {
    return req.respond({ status: 200, contentType: "image/png", headers: { "access-control-allow-origin": "*" }, body: fs.readFileSync("/tmp/bt/poster.png") });
  }
  return req.continue();
});

// Home page on a fresh browser
await page.goto(`${BASE}/`, { waitUntil: "networkidle0" });
await sleep(600);
let home = await page.evaluate(() => ({ url: location.pathname, text: document.querySelector("main").innerText, h1: document.querySelector("h1")?.textContent, active: document.querySelector("aside a[aria-current=page]")?.textContent.trim() }));
check("the site opens on Home, not the journal", home.url === "/" && /Home/.test(home.active), JSON.stringify(home));
check("first time visitors get a welcome", /Welcome to Life Trail/.test(home.text), home.text.slice(0, 200));
check("greeting is shown", /Good (morning|afternoon|evening)|Still up/.test(home.h1), home.h1);
await page.screenshot({ path: "/tmp/bt/shots/home-empty.png" });

// key for TMDB
await page.evaluate(() => new Promise((res) => { const r = indexedDB.open("life-trail-backups"); r.onsuccess = () => { const db = r.result; const tx = db.transaction("settings", "readwrite"); tx.objectStore("settings").put({ key: "tmdbKey", value: "0123456789abcdef0123456789abcdef" }); tx.oncomplete = res; }; }));

// search finds shows
await page.goto(`${BASE}/movies/add/`, { waitUntil: "networkidle0" });
await page.type("input[type=search]", "Loki");
await page.waitForSelector("ul button", { timeout: 6000 });
const rows = await page.evaluate(() => [...document.querySelectorAll("ul button")].map((b) => b.innerText.replace(/\n/g, " | ")));
console.log(JSON.stringify(rows));
check("search lists movies and shows, not people", rows.length === 2, rows.length);
check("shows carry a Show badge and movies a Movie badge", rows[1].includes("Show") && rows[0].includes("Movie"), JSON.stringify(rows));
check("TMDB was asked through the multi search", requests.some((u) => u.includes("/3/search/multi?")), requests.join("\n"));
await page.screenshot({ path: "/tmp/bt/shots/search.png" });

// log the show
await (await page.$$("ul button"))[1].click();
await sleep(400);
const h = await page.evaluate(() => ({ title: document.querySelector("h1").textContent, badge: document.querySelector("main")?.innerText.includes("Show") }));
check("picking a show says Log a show", h.title === "Log a show", JSON.stringify(h));
await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => /^5 stars?$|Rate 5|5 star/i.test(b.getAttribute("aria-label") ?? ""))?.click());
const stars = await page.$$("[role=radio], button[aria-label*='star']");
if (stars.length) await stars[Math.min(9, stars.length - 1)].click();
await page.type("textarea", "Season one was a blast.");
await page.keyboard.down("Control"); await page.keyboard.press("Enter"); await page.keyboard.up("Control");
await page.waitForFunction(() => location.pathname.includes("/movies/log"), { timeout: 8000 }).catch(() => {});
await sleep(600);
const detail = await page.evaluate(() => ({ url: location.pathname, text: document.querySelector("article")?.innerText ?? document.querySelector("main").innerText }));
check("the show was saved as a viewing", detail.url.includes("/movies/log") && /Loki/.test(detail.text) && /Show/.test(detail.text), detail.text.slice(0, 200));
check("viewing page says other viewings of this show", /Other viewings of this show/.test(detail.text), detail.text);

// log a movie by hand too
await page.goto(`${BASE}/movies/add/`, { waitUntil: "networkidle0" });
await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.includes("Type the title myself")).click());
await sleep(300);
const manual = await page.evaluate(() => ({ seg: [...document.querySelectorAll("[role=group] button")].map((b) => b.textContent), ph: document.querySelector("input[type=text]").placeholder }));
check("manual form offers Movie and Show", manual.seg.includes("Movie") && manual.seg.includes("Show") && manual.ph === "Movie title", JSON.stringify(manual));
await page.evaluate(() => [...document.querySelectorAll("[role=group] button")].find((b) => b.textContent === "Show").click());
await sleep(200);
check("choosing Show changes the title field", await page.evaluate(() => document.querySelector("input[type=text]").placeholder) === "Show title");
await page.evaluate(() => { document.querySelector("input[type=text]").focus(); });
await page.keyboard.type("Hand Made Show");
const stars2 = await page.$$("button[aria-label*='star']");
if (stars2.length) await stars2[Math.min(5, stars2.length - 1)].click();
await page.keyboard.down("Control"); await page.keyboard.press("Enter"); await page.keyboard.up("Control");
await page.waitForFunction(() => location.pathname.includes("/movies/log"), { timeout: 8000 }).catch(() => {});

// seed a film directly so the list has both
await page.goto(`${BASE}/movies/`, { waitUntil: "networkidle0" });
await page.evaluate(() => new Promise((res) => {
  const r = indexedDB.open("life-trail");
  r.onsuccess = () => {
    const db = r.result; const tx = db.transaction(["movies", "movieLogs"], "readwrite");
    const q = tx.objectStore("movies").add({ kind: "movie", tmdbId: 777, title: "A Plain Film", year: 2001, overview: "", posterPath: null, posterData: null, createdAt: Date.now(), fetchedAt: Date.now() });
    q.onsuccess = () => tx.objectStore("movieLogs").add({ movieId: q.result, rating: 3.5, opinion: "", watchedDate: new Date().toISOString().slice(0, 10), createdAt: Date.now(), updatedAt: Date.now() });
    tx.oncomplete = res;
  };
}));
await page.reload({ waitUntil: "networkidle0" });
await sleep(500);
const list = await page.evaluate(() => ({
  h1: document.querySelector("h1").textContent,
  btn: [...document.querySelectorAll("header a")].map((a) => a.textContent.trim()),
  cards: [...document.querySelectorAll("ul > li")].map((l) => l.innerText.replace(/\n/g, " | ")),
  stats: [...document.querySelectorAll("p")].map((p) => p.textContent).find((t) => /average rating/.test(t)),
  nav: document.querySelector("aside nav").innerText,
}));
console.log(JSON.stringify(list));
check("page and button say Movies/Shows", list.h1 === "Movies/Shows" && list.btn.includes("Log a movie or show"), JSON.stringify(list));
check("sidebar says Movies/Shows", /Movies\/Shows/.test(list.nav));
check("show cards are marked", list.cards.some((c) => c.includes("Loki") && c.includes("Show")), JSON.stringify(list.cards));
check("stats count both kinds", /movie/.test(list.stats) && /show/.test(list.stats), list.stats);
await page.screenshot({ path: "/tmp/bt/shots/movies-mixed.png" });

const clickKind = async (name) => { await page.evaluate((n) => [...document.querySelectorAll("[aria-label='Show only'] button")].find((b) => b.textContent === n).click(), name); await sleep(300); };
await clickKind("Shows");
let titles = await page.evaluate(() => [...document.querySelectorAll("ul > li")].map((l) => l.innerText));
check("Shows filter keeps only shows", titles.length === 2 && titles.every((t) => /Loki|Hand Made Show/.test(t)), JSON.stringify(titles));
check("stats follow the filter", !/movie/.test(await page.evaluate(() => [...document.querySelectorAll("p")].map((p) => p.textContent).find((t) => /average rating/.test(t)))));
await clickKind("Movies");
titles = await page.evaluate(() => [...document.querySelectorAll("ul > li")].map((l) => l.innerText));
check("Movies filter keeps only films", titles.length === 1 && titles[0].includes("A Plain Film"), JSON.stringify(titles));
await clickKind("All");

// Home with data
await page.goto(`${BASE}/`, { waitUntil: "networkidle0" });
await sleep(600);
await page.screenshot({ path: "/tmp/bt/shots/home-data.png", fullPage: true });
home = await page.evaluate(() => document.querySelector("main").innerText);
check("home lists recently watched with show marker", /Recently watched/.test(home) && /Show/.test(home), home.slice(0, 500));

// add an entry for today and an entry from a previous year for On this day
await page.evaluate(() => new Promise((res) => {
  const r = indexedDB.open("life-trail");
  r.onsuccess = () => {
    const db = r.result;
    const tagsReq = db.transaction("tags").objectStore("tags").getAll();
    tagsReq.onsuccess = () => {
      const tags = tagsReq.result; const d = new Date();
      const key = (y) => `${y}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      const tx = db.transaction("entries", "readwrite"); const s = tx.objectStore("entries");
      s.add({ date: key(d.getFullYear()), title: "Today's note", body: "**hello** [x](https://a.com)", tagIds: [tags[0].id], createdAt: Date.now(), updatedAt: Date.now() });
      s.add({ date: key(d.getFullYear() - 1), title: "A year ago", body: "old", tagIds: [tags[1].id], createdAt: 1, updatedAt: 1 });
      tx.oncomplete = res;
    };
  };
}));
await page.reload({ waitUntil: "networkidle0" });
await sleep(700);
const full = await page.evaluate(() => ({ text: document.querySelector("main").innerText, tiles: document.querySelectorAll("section ul li a[title]").length, links: [...document.querySelectorAll("main a")].map((a) => a.getAttribute("href")) }));
check("home notices you wrote today", /You have written 1 entry today/.test(full.text), full.text.slice(0, 300));
check("home shows On this day", /On this day/.test(full.text) && /1 year ago/.test(full.text) && /A year ago/.test(full.text), full.text);
check("recent entries show plain text previews", /Today's note/.test(full.text) && !full.text.includes("**"));
check("seven day strip has seven tiles", full.tiles === 7, full.tiles);
check("home has quick links", full.links.includes("/journal/new/") && full.links.some((l) => l?.startsWith("/journal/entry/?id=")));
await page.screenshot({ path: "/tmp/bt/shots/home-full.png", fullPage: true });

// logo goes home
await page.goto(`${BASE}/journal/`, { waitUntil: "networkidle0" });
await page.click("aside a[aria-label='Life Trail home']");
await page.waitForFunction(() => location.pathname === "/", { timeout: 5000 }).catch(() => {});
check("sidebar logo goes home", new URL(page.url()).pathname === "/", page.url());

// phone width
await page.setViewport({ width: 360, height: 740 });
await page.goto(`${BASE}/`, { waitUntil: "networkidle0" });
await sleep(500);
const phone = await page.evaluate(() => {
  const nav = document.querySelector("nav.border-t");
  const items = [...nav.querySelectorAll("a")];
  return { labels: items.map((a) => a.innerText.replace(/\n/g, " ").trim()), overflow: nav.scrollWidth > nav.clientWidth, h: nav.getBoundingClientRect().height, docOverflow: document.documentElement.scrollWidth > window.innerWidth };
});
console.log(JSON.stringify(phone));
check("phone bar fits six items without overflow", phone.labels.length === 6 && !phone.overflow && !phone.docOverflow, JSON.stringify(phone));
await page.screenshot({ path: "/tmp/bt/shots/home-phone.png" });

check("no page errors", errors.length === 0, errors.join("\n"));
await browser.close();
console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
