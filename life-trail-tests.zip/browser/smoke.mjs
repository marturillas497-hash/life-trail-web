import chromium from "@sparticuz/chromium";
import puppeteer from "puppeteer-core";

const browser = await puppeteer.launch({
  args: [...chromium.args, "--no-sandbox"],
  executablePath: await chromium.executablePath(),
  headless: "shell",
});
const page = await browser.newPage();
await page.setContent("<h1>hello</h1>");
console.log("title text:", await page.$eval("h1", (e) => e.textContent));
console.log("UA:", await browser.version());
await browser.close();
