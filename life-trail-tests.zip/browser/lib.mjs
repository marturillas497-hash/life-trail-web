import chromium from "@sparticuz/chromium";
import puppeteer from "puppeteer-core";

export async function launch() {
  return puppeteer.launch({
    args: [...chromium.args, "--no-sandbox"],
    executablePath: await chromium.executablePath(),
    headless: "shell",
  });
}
export const BASE = "http://localhost:3300";
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
