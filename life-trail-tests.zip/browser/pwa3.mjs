import { execSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { launch, BASE, sleep } from "./lib.mjs";

const browser = await launch();
const page = await browser.newPage();
let failures = 0;
const check = (label, ok, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };
const bodyText = () => page.evaluate(() => document.body.innerText);

await page.setViewport({ width: 1280, height: 800 });
await page.goto(BASE + "/journal/", { waitUntil: "networkidle0" });
await page.evaluate(() => navigator.serviceWorker.ready);
for (let i = 0; i < 40 && !(await page.evaluate(() => !!navigator.serviceWorker.controller)); i++) await sleep(250);
const v1 = (await page.evaluate(() => caches.keys()))[0];
check("v1 installed and in control", !!v1, v1);

// ship version 2: a real code change, then the real build
const file = "/home/claude/verify/src/components/lock/PinField.tsx";
const before = readFileSync(file, "utf8");
const after = before.replace('className={`${inputClass} text-center text-xl tracking-[0.4em]`}', 'className={`${inputClass} text-center ${value ? "text-xl tracking-[0.4em]" : "text-base"}`}');
if (after === before) throw new Error("edit did not apply");
writeFileSync(file, after);
console.log("building version 2 ...");
execSync("npm run build", { cwd: "/home/claude/verify", stdio: "pipe" });

// the open tab checks for an update (it also does this when you come back to it)
await page.evaluate(async () => { const reg = await navigator.serviceWorker.getRegistration(); await reg.update(); });
await page.waitForFunction(() => document.body.innerText.includes("A new version of Life Trail is ready"), { timeout: 20000 });
check("update bar appears while the old version keeps running", true);
const stillV1 = (await page.evaluate(() => caches.keys())).includes(v1);
check("old cache is untouched until the person reloads", stillV1);
check("page was not reloaded behind the person's back", await page.evaluate(() => performance.getEntriesByType("navigation").length === 1 && !document.body.innerText.includes("Loading...")));
await page.screenshot({ path: "shots/70-update-bar.png" });

// press the button
await Promise.all([
  page.waitForNavigation({ waitUntil: "networkidle0", timeout: 20000 }),
  page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.trim() === "Reload to update").click()),
]);
await sleep(1500);
const names = await page.evaluate(() => caches.keys());
check("after reload exactly one cache remains, and it is new", names.length === 1 && names[0] !== v1, JSON.stringify(names));
check("update bar is gone after updating", !(await bodyText()).includes("A new version of Life Trail is ready"));
check("app still works after updating", (await bodyText()).includes("Journal"));

// the new code is what is being served from the cache
const served = await page.evaluate(async () => {
  const cache = await caches.open((await caches.keys())[0]);
  const keys = await cache.keys();
  let found = false;
  for (const req of keys) { if (!req.url.endsWith(".js")) continue; const text = await (await cache.match(req)).text(); if (text.includes("text-base")) { found = true; break; } }
  return found;
});
check("cached files contain the version 2 change", served);

await browser.close();
console.log(failures === 0 ? "ALL PASSED" : failures + " FAILED");
