import { launch, BASE, sleep } from "./lib.mjs";
const browser = await launch();
const errors = [];
const page = await browser.newPage();
page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
let failures = 0;
const check = (label, ok, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };
const clickText = (text, tag = "button") => page.evaluate((text, tag) => {
  const el = [...document.querySelectorAll(tag)].find((e) => e.textContent.trim() === text);
  if (!el) return false; el.click(); return true;
}, text, tag);
const bodyText = () => page.evaluate(() => document.body.innerText);

await page.setViewport({ width: 1280, height: 800 });
await page.goto(BASE + "/journal/", { waitUntil: "networkidle0" });

// ---- installability
const cdp = await page.createCDPSession();
const { installabilityErrors } = await cdp.send("Page.getInstallabilityErrors");
check("no installability errors", installabilityErrors.length === 0, JSON.stringify(installabilityErrors));
const manifestHref = await page.$eval('link[rel="manifest"]', (l) => l.href);
check("manifest linked", manifestHref.endsWith("/manifest.webmanifest"), manifestHref);
const theme = await page.$$eval('meta[name="theme-color"]', (m) => m.map((x) => x.content));
check("theme color meta present", theme.length >= 1, JSON.stringify(theme));
check("apple touch icon linked", (await page.$$eval('link[rel="apple-touch-icon"]', (l) => l.length)) >= 1);

// ---- service worker + cache
await page.evaluate(() => navigator.serviceWorker.ready);
for (let i = 0; i < 40 && !(await page.evaluate(() => !!navigator.serviceWorker.controller)); i++) await sleep(250);
check("service worker controls the page", await page.evaluate(() => !!navigator.serviceWorker.controller));
const cacheInfo = await page.evaluate(async () => {
  const names = await caches.keys();
  const cache = await caches.open(names[0]);
  return { names, count: (await cache.keys()).length };
});
check("one versioned cache with the app files", cacheInfo.names.length === 1 && cacheInfo.count >= 80, JSON.stringify(cacheInfo));

// ---- create an entry online
await page.click('a[href="/journal/new/"]');
await page.waitForSelector('input[aria-label="Title"]');
await sleep(400);
const chips = await page.$$("button[aria-pressed]");
await chips[0].click();
await page.type('input[aria-label="Title"]', "Written online");
await page.type('textarea[aria-label="Entry text"]', "This one was saved while online.");
await page.keyboard.down("Control"); await page.keyboard.press("s"); await page.keyboard.up("Control");
await page.waitForFunction(() => location.pathname.startsWith("/journal/entry"), { timeout: 8000 });
check("entry saved online, detail page shows", true);
await sleep(500);

// ======== OFFLINE ========
await page.setOfflineMode(true);
await page.reload({ waitUntil: "networkidle0" });
await sleep(800);
let t = await bodyText();
check("OFFLINE: reload shows the app and the saved entry", t.includes("Written online"), t.slice(0, 200));
await page.screenshot({ path: "shots/40-offline-journal.png" });

for (const [label, expected] of [["Calendar", "October 2026"], ["Tags", "Used in"], ["Backup", "Backup and restore"], ["Settings", "Install the app"]]) {
  await page.evaluate((label) => { [...document.querySelectorAll("aside a")].find((a) => a.textContent.includes(label)).click(); }, label);
  await sleep(900);
  t = await bodyText();
  check(`OFFLINE: client navigation to ${label}`, t.includes(expected), t.slice(0, 150));
}

// open the entry, edit page, new form
await page.goto(BASE + "/journal/", { waitUntil: "networkidle0" });
await sleep(600);
await page.click("ul a"); await sleep(700);
check("OFFLINE: open an entry from the list", (await bodyText()).includes("This one was saved while online."));
await clickText("Edit", "a"); await sleep(800);
check("OFFLINE: edit page opens with the text", await page.$eval('textarea[aria-label="Entry text"]', (e) => e.value).then((v) => v.includes("saved while online")));

// emoji picker chunk (lazy loaded) while offline
await page.goto(BASE + "/tags/", { waitUntil: "networkidle0" }); await sleep(600);
await clickText("New tag"); await sleep(2000);
const pickerOffline = await page.evaluate(() => !!document.querySelector("button.epr-emoji, .epr-emoji-category"));
check("OFFLINE: emoji picker (lazy chunk) renders", pickerOffline);
await clickText("Cancel");

// hard navigations offline
for (const [url, expected] of [["/calendar/", "October 2026"], ["/help/", "How your backups work"], ["/journal/entry/?id=1", "Written online"], ["/journal/entry/edit/?id=1", "Edit entry"], ["/settings/", "App lock"], ["/journal/new/", "How are you feeling?"]]) {
  await page.goto(BASE + url, { waitUntil: "networkidle0" }); await sleep(700);
  t = await bodyText();
  check(`OFFLINE: direct visit ${url}`, t.includes(expected), t.slice(0, 120));
}
// slashless URL falls back to the slash version
await page.goto(BASE + "/calendar", { waitUntil: "networkidle0" }); await sleep(600);
check("OFFLINE: URL without trailing slash works", (await bodyText()).includes("October 2026"));

// write a new entry while offline
await page.goto(BASE + "/journal/new/", { waitUntil: "networkidle0" });
await page.waitForSelector('input[aria-label="Title"]'); await sleep(400);
const chips3 = await page.$$("button[aria-pressed]"); await chips3[3].click();
await page.type('input[aria-label="Title"]', "Written offline");
await page.type('textarea[aria-label="Entry text"]', "Airplane mode entry.");
await page.keyboard.down("Control"); await page.keyboard.press("s"); await page.keyboard.up("Control");
await page.waitForFunction(() => location.pathname.startsWith("/journal/entry"), { timeout: 8000 });
await page.goto(BASE + "/journal/", { waitUntil: "networkidle0" }); await sleep(600);
t = await bodyText();
check("OFFLINE: new entry saved and listed", t.includes("Written offline") && t.includes("Written online"));

// back online, data still there
await page.setOfflineMode(false);
await page.reload({ waitUntil: "networkidle0" }); await sleep(600);
check("back online: both entries still there", (await bodyText()).includes("Written offline"));

await browser.close();
console.log(errors.length ? "CONSOLE ERRORS:\n" + [...new Set(errors)].join("\n") : "no console errors");
console.log(failures === 0 ? "ALL PASSED" : failures + " FAILED");
