import puppeteer from "puppeteer-core";

const BASE = "http://localhost:3300";
let failures = 0;
const check = (label, ok, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : String(extra)); if (!ok) failures++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await puppeteer.launch({
  executablePath: "/opt/google/chrome/chrome",
  headless: "new",
  args: ["--no-sandbox", "--disable-gpu"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 900 });
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
await page.evaluateOnNewDocument(() => {
  window.__opened = [];
  window.open = (url) => { window.__opened.push(String(url)); return null; };
});

await page.goto(`${BASE}/journal/new/`, { waitUntil: "networkidle0" });
await page.waitForSelector(".cm-content");

// pick a tag
const chips = await page.$$("button[aria-pressed]");
await chips[0].click();

// type markdown
await page.click(".cm-content");
const type = (text) => page.keyboard.type(text, { delay: 2 });
await type("# Big day");
await page.keyboard.press("Enter");
await type("Some **bold** and *italic* and ~~gone~~ and `code`.");
await page.keyboard.press("Enter");
await type("Visit [Example](https://example.com/page) or https://bare.example.org now.");
await page.keyboard.press("Enter");
await type("- first");
await page.keyboard.press("Enter");
await type("second");
await page.keyboard.press("Enter");
await page.keyboard.press("Enter");
await type("- [ ] todo item");
await page.keyboard.press("Enter");
await type("done thing");
await page.keyboard.press("Enter");
await page.keyboard.press("Enter");
await type("> a quote");
await page.keyboard.press("Enter");
await page.keyboard.press("Enter");

const doc = await page.evaluate(() => document.querySelector(".cm-content").innerText);
check("typed text is in the editor", doc.includes("Big day") && doc.includes("Example"));
// list continuation: second item got its own "- "
const raw = await page.evaluate(() => [...document.querySelectorAll(".cm-line")].map((l) => l.textContent));
console.log(JSON.stringify(raw));
check("Enter continues a bullet list", raw.filter((l) => l.startsWith("•")).length >= 2, raw.join("|"));
check("Enter continues a task list", raw.filter((l) => l.includes("todo item") || l.includes("done thing")).length === 2, raw.join("|"));

// move focus out so everything renders
await page.click("input[aria-label=Title]");
await sleep(150);
const rendered = await page.evaluate(() => ({
  h1: !!document.querySelector(".cm-h1"),
  h1Text: document.querySelector(".cm-h1")?.textContent,
  strong: document.querySelector(".cm-strong")?.textContent,
  em: document.querySelector(".cm-em")?.textContent,
  strike: !!document.querySelector(".cm-strike"),
  code: document.querySelector(".cm-inline-code")?.textContent,
  links: [...document.querySelectorAll(".cm-link")].map((e) => [e.textContent, e.dataset.url]),
  bullets: document.querySelectorAll(".cm-bullet").length,
  tasks: document.querySelectorAll("input.cm-task").length,
  quote: !!document.querySelector(".cm-quote"),
}));
console.log(JSON.stringify(rendered));
check("heading rendered without #", rendered.h1 && rendered.h1Text === "Big day", rendered.h1Text);
check("bold rendered without **", rendered.strong === "bold", rendered.strong);
check("italic rendered", rendered.em === "italic", rendered.em);
check("strikethrough + inline code", rendered.strike && rendered.code === "code", rendered.code);
check("link label shown, url hidden", rendered.links[0]?.[0] === "Example" && rendered.links[0]?.[1] === "https://example.com/page", JSON.stringify(rendered.links));
check("bare url is a link", rendered.links.some((l) => l[1] === "https://bare.example.org"), JSON.stringify(rendered.links));
check("bullets and checkbox widgets", rendered.bullets === 2 && rendered.tasks === 2, JSON.stringify(rendered));
check("quote styled", rendered.quote);

// cursor on the heading line reveals the marker
await page.click(".cm-h1");
await sleep(100);
const revealed = await page.evaluate(() => document.querySelector(".cm-h1")?.textContent);
check("clicking a heading reveals its #", revealed === "# Big day", revealed);

// Ctrl+Enter on a link
await page.click(".cm-link");
await sleep(100);
await page.keyboard.down("Control");
await page.keyboard.press("Enter");
await page.keyboard.up("Control");
let opened = await page.evaluate(() => window.__opened);
check("Ctrl+Enter opens the link", opened.length === 1 && opened[0] === "https://example.com/page", JSON.stringify(opened));

// Ctrl+Click
await page.click("input[aria-label=Title]");
await sleep(100);
await page.keyboard.down("Control");
await page.click(".cm-link");
await page.keyboard.up("Control");
opened = await page.evaluate(() => window.__opened);
check("Ctrl+Click opens the link", opened.length === 2 && opened[1] === "https://example.com/page", JSON.stringify(opened));

// Task checkbox toggles
await page.click("input[aria-label=Title]");
await sleep(100);
const box = await page.$("input.cm-task");
await box.click();
await sleep(100);
const lines2 = await page.evaluate(() => [...document.querySelectorAll(".cm-line")].map((l) => l.textContent));
await page.click(".cm-h1"); // reveal for reading source
const srcLines = await page.evaluate(() => [...document.querySelectorAll(".cm-line")].map((l) => l.textContent).join("\n"));
check("clicking the checkbox ticks it in the text", /- \[x\] todo item/i.test(srcLines) || lines2.some((l) => /todo item/.test(l)), srcLines);

// Ctrl+B wraps selection
await page.click("input[aria-label=Title]");
await page.click(".cm-content");
await page.keyboard.down("Control"); await page.keyboard.press("End"); await page.keyboard.up("Control");
await type("plain");
await page.keyboard.down("Shift");
for (let i = 0; i < 5; i++) await page.keyboard.press("ArrowLeft");
await page.keyboard.up("Shift");
await page.keyboard.down("Control"); await page.keyboard.press("b"); await page.keyboard.up("Control");
const tail = await page.evaluate(() => { const l = [...document.querySelectorAll(".cm-line")]; return l[l.length - 1].textContent; });
check("Ctrl+B makes the selection bold", tail.includes("**plain**"), tail);

// ---------- pictures ----------
await page.click(".cm-content");
await page.keyboard.down("Control"); await page.keyboard.press("End"); await page.keyboard.up("Control");
await page.keyboard.press("Enter");
const input = await page.$("[data-testid=picture-input]");
await input.uploadFile("/tmp/bt/big.png");
await page.waitForFunction(() => document.querySelector(".cm-content").textContent.includes("image:"), { timeout: 8000 }).catch(() => {});
await sleep(300);
const imgInfo = await page.evaluate(async () => {
  const dbs = await indexedDB.databases();
  return new Promise((resolve) => {
    const req = indexedDB.open("life-trail");
    req.onsuccess = () => {
      const tx = req.result.transaction("images");
      const all = tx.objectStore("images").getAll();
      all.onsuccess = () => resolve(all.result.map((r) => ({ id: r.id, name: r.name, type: r.type, w: r.width, h: r.height, bytes: r.data.byteLength })));
    };
  });
});
console.log(JSON.stringify(imgInfo));
check("picture stored, shrunk to 1600 wide and smaller on disk", imgInfo.length === 1 && imgInfo[0].w === 1600 && imgInfo[0].h === 800 && imgInfo[0].bytes < 909791, JSON.stringify(imgInfo));
check("stored as webp", imgInfo[0]?.type === "image/webp", imgInfo[0]?.type);

await page.click("input[aria-label=Title]");
await sleep(500);
const imgDom = await page.evaluate(() => {
  const img = document.querySelector(".cm-image img");
  return img ? { w: img.naturalWidth, shown: img.getBoundingClientRect().width, src: img.src.slice(0, 5) } : null;
});
check("picture renders inline", imgDom && imgDom.w === 1600 && imgDom.src === "blob:", JSON.stringify(imgDom));
check("picture fits the editor", imgDom && imgDom.shown <= 680, JSON.stringify(imgDom));

// paste an image
await page.click(".cm-content");
await page.evaluate(() => {
  const canvas = document.createElement("canvas"); canvas.width = 40; canvas.height = 30;
  canvas.getContext("2d").fillStyle = "#c33"; canvas.getContext("2d").fillRect(0, 0, 40, 30);
  return new Promise((resolve) => canvas.toBlob((blob) => {
    const file = new File([blob], "pasted.png", { type: "image/png" });
    const dt = new DataTransfer(); dt.items.add(file);
    document.querySelector(".cm-content").dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    resolve();
  }, "image/png"));
});
await sleep(800);
await page.click("input[aria-label=Title]");
await sleep(500);
const count = await page.evaluate(() => document.querySelectorAll(".cm-image img").length);
check("pasting a picture adds a second one", count === 2, `${count}`);

// non-image file gives a message
const bad = "/tmp/bt/notes.txt"; (await import("node:fs")).writeFileSync(bad, "hi");
await page.evaluate(() => { document.querySelector("[data-testid=picture-input]").removeAttribute("accept"); });
await (await page.$("[data-testid=picture-input]")).uploadFile(bad);
await sleep(300);
const alertText = await page.evaluate(() => document.querySelector("[role=alert]")?.textContent ?? null);
console.log("alert:", alertText);

await page.screenshot({ path: "/tmp/bt/shots/editor-light.png" });

// ---------- save and view ----------
await page.click("input[aria-label=Title]");
await page.type("input[aria-label=Title]", "Markdown test");
await page.keyboard.down("Control"); await page.keyboard.press("s"); await page.keyboard.up("Control");
await page.waitForFunction(() => location.pathname.includes("/journal/entry"), { timeout: 8000 }).catch(() => {});
await sleep(1200);
const viewState = await page.evaluate(() => ({
  url: location.href,
  h1: document.querySelector(".lt-md-view .cm-h1")?.textContent,
  imgs: [...document.querySelectorAll(".lt-md-view .cm-image img")].map((i) => i.naturalWidth),
  link: document.querySelector(".lt-md-view .cm-link")?.dataset.url,
  editable: document.querySelector(".lt-md-view .cm-content")?.getAttribute("contenteditable"),
  tasks: document.querySelectorAll(".lt-md-view input.cm-task").length,
  disabled: document.querySelector(".lt-md-view input.cm-task")?.disabled,
}));
console.log(JSON.stringify(viewState));
check("saved entry shows rendered markdown", viewState.h1 === "Big day", JSON.stringify(viewState));
check("saved entry shows both pictures", viewState.imgs.length === 2 && viewState.imgs.includes(1600) && viewState.imgs.includes(40), JSON.stringify(viewState.imgs));
check("reader is not editable", viewState.editable === "false", viewState.editable);
check("reader checkboxes are disabled", viewState.tasks >= 1 && viewState.disabled === true);
await page.click(".lt-md-view .cm-link");
const openedView = await page.evaluate(() => window.__opened);
check("plain click on a link opens it in the reader", openedView.at(-1) === "https://example.com/page", JSON.stringify(openedView));
await page.screenshot({ path: "/tmp/bt/shots/view-light.png", fullPage: true });

// list preview is plain
await page.goto(`${BASE}/journal/`, { waitUntil: "networkidle0" });
await sleep(400);
const preview = await page.evaluate(() => document.querySelector("main")?.innerText ?? "");
check("journal list preview has no markdown symbols", !preview.includes("**") && !preview.includes("](") && !preview.includes("image:"), preview.slice(0, 300));

// sidebar collapse persists across a reload
await page.click("button[aria-label='Collapse sidebar']");
await sleep(500);
const narrow = await page.evaluate(() => document.querySelector("aside").getBoundingClientRect().width);
check("sidebar collapses to icons", narrow < 100, narrow);
await page.reload({ waitUntil: "networkidle0" });
const afterReload = await page.evaluate(() => ({ attr: document.documentElement.dataset.sidebar, w: document.querySelector("aside").getBoundingClientRect().width }));
check("collapsed sidebar stays collapsed after reload", afterReload.attr === "collapsed" && afterReload.w < 100, JSON.stringify(afterReload));
await page.click("button[aria-label='Expand sidebar']");
await sleep(500);
const wide = await page.evaluate(() => document.querySelector("aside").getBoundingClientRect().width);
check("sidebar expands again", wide > 200, wide);

// backup page: pictures card and a downloaded file that includes pictures
await page.goto(`${BASE}/backup/`, { waitUntil: "networkidle0" });
await sleep(500);
const backupText = await page.evaluate(() => document.querySelector("main").innerText);
check("backup page shows the pictures card", /Pictures/.test(backupText) && /2 pictures/.test(backupText), backupText.slice(0, 400));
const built = await page.evaluate(async () => {
  const mod = null; return mod;
});

// dark mode screenshot of the entry
await page.evaluate(() => localStorage.setItem("life-trail-theme", "dark"));
await page.goto(`${BASE}/journal/entry/?id=1`, { waitUntil: "networkidle0" });
await sleep(800);
await page.screenshot({ path: "/tmp/bt/shots/view-dark.png", fullPage: true });
check("no page errors", errors.length === 0, errors.join("\n"));
await browser.close();
console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
