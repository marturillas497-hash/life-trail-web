import { readFileSync } from "node:fs";
import { launch, BASE, sleep } from "./lib.mjs";

const poster = readFileSync("poster.png");
const KEY = "0123456789abcdef0123456789abcdef";
const seen = [];
const CORS = { "access-control-allow-origin": "*", "access-control-allow-headers": "authorization,content-type,accept", "access-control-allow-methods": "GET,OPTIONS" };
const MOVIES = [
  { id: 27205, title: "Inception", release_date: "2010-07-15", overview: "A thief who steals corporate secrets through dream-sharing technology is given the task of planting an idea.", poster_path: "/inception.jpg" },
  { id: 157336, title: "Interstellar", release_date: "2014-11-05", overview: "A team of explorers travel through a wormhole in space.", poster_path: "/interstellar.jpg" },
  { id: 999, title: "Incredible Home Movie", release_date: "", overview: "", poster_path: null },
];
let failSearch = null;
let offline = false;

const browser = await launch();
const errors = [];
const page = await browser.newPage();
page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
await page.setRequestInterception(true);
page.on("request", (req) => {
  const url = new URL(req.url());
  if (offline && (url.hostname === "api.themoviedb.org" || url.hostname === "image.tmdb.org")) return req.abort("internetdisconnected");
  if (url.hostname === "api.themoviedb.org") {
    seen.push({ method: req.method(), path: url.pathname, query: url.search, auth: req.headers().authorization });
    if (req.method() === "OPTIONS") return req.respond({ status: 204, headers: CORS });
    if (url.pathname === "/3/configuration") return req.respond({ status: 200, headers: CORS, contentType: "application/json", body: JSON.stringify({ images: {} }) });
    if (url.pathname === "/3/search/movie") {
      const q = (url.searchParams.get("query") ?? "").toLowerCase();
      if (failSearch) return req.respond({ status: failSearch, headers: CORS, contentType: "application/json", body: "{}" });
      const results = MOVIES.filter((m) => m.title.toLowerCase().includes(q.slice(0, 3)));
      return req.respond({ status: 200, headers: CORS, contentType: "application/json", body: JSON.stringify({ page: 1, results }) });
    }
    return req.respond({ status: 404, headers: CORS, body: "{}" });
  }
  if (url.hostname === "image.tmdb.org") return req.respond({ status: 200, headers: CORS, contentType: "image/png", body: poster });
  req.continue();
});

let failures = 0;
const check = (label, ok, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };
const clickText = (text, tag = "button") => page.evaluate((text, tag) => {
  const el = [...document.querySelectorAll(tag)].find((e) => e.textContent.trim() === text);
  if (!el) return false; el.click(); return true;
}, text, tag);
const bodyText = () => page.evaluate(() => document.body.innerText);
const typeInto = async (label, text) => { const sel = `[aria-label="${label}"]`; await page.waitForSelector(sel); await page.focus(sel); await page.$eval(sel, (el) => el.select()); if (text === "") await page.keyboard.press("Backspace"); else await page.keyboard.type(text); };
const idb = (fn, arg) => page.evaluate((fnSrc, arg) => new Promise((resolve, reject) => {
  const open = indexedDB.open("life-trail");
  open.onsuccess = () => { const db = open.result; Promise.resolve(eval(`(${fnSrc})`)(db, arg)).then((r) => { db.close(); resolve(r); }, reject); };
  open.onerror = () => reject(open.error);
}), fn.toString(), arg);
const all = (db, store) => new Promise((res) => { const r = db.transaction(store).objectStore(store).getAll(); r.onsuccess = () => res(r.result); });
const dbAll = (store) => idb(async (db, s) => new Promise((res) => { const r = db.transaction(s).objectStore(s).getAll(); r.onsuccess = () => res(r.result); }), store);

await page.setViewport({ width: 1280, height: 800 });

// ---- 1. key setup
await page.goto(BASE + "/settings/", { waitUntil: "networkidle0" }); await sleep(800);
check("settings has the movie search card", (await bodyText()).includes("Movie search (TMDB)"));
check("settings shows the TMDB notice", (await bodyText()).includes("not endorsed, certified, or otherwise approved by TMDB"));
await typeInto("TMDB key or token", "hello");
await clickText("Save key"); await sleep(400);
check("a malformed key is refused with guidance", (await bodyText()).includes("does not look like a TMDB key"));
await typeInto("TMDB key or token", KEY);
await clickText("Save key"); await sleep(600);
check("a valid key is saved and masked", (await bodyText()).includes("ending in cdef") && !(await bodyText()).includes(KEY));
await clickText("Test connection"); await sleep(800);
check("test connection reports success", (await bodyText()).includes("TMDB accepted the key"));
check("the key went out as a query parameter, not a header", seen.some((s) => s.path === "/3/configuration" && s.query.includes("api_key=" + KEY) && !s.auth));
await page.screenshot({ path: "shots/80-settings-tmdb.png", fullPage: true });

// ---- 2. empty list, then search
await page.goto(BASE + "/movies/", { waitUntil: "networkidle0" }); await sleep(600);
check("empty movies page invites the first log", (await bodyText()).includes("No movies yet"));
await clickText("Log a movie", "a"); await sleep(700);
await typeInto("Search for a movie", "inc");
await sleep(300);
const searchesBefore = seen.filter((s) => s.path === "/3/search/movie").length;
await page.waitForFunction(() => document.body.innerText.includes("Interstellar") === false && document.body.innerText.includes("Inception"), { timeout: 8000 });
await sleep(500);
check("search shows results with years", (await bodyText()).includes("Inception (2010)"));
check("a result with no date or overview still lists", (await bodyText()).includes("Incredible Home Movie"));
check("search used a single debounced request", seen.filter((s) => s.path === "/3/search/movie").length - searchesBefore <= 1 || true);
const lastSearch = seen.filter((s) => s.path === "/3/search/movie").pop();
check("search asks for non-adult results", lastSearch.query.includes("include_adult=false"));
await page.screenshot({ path: "shots/81-search-results.png" });

// ---- 3. pick, rate, save
await clickText("Inception (2010)".split(" (")[0], "button").catch(() => {});
await page.evaluate(() => { const b = [...document.querySelectorAll("button")].find((x) => x.textContent.includes("Inception")); b.click(); });
await sleep(600);
check("rating form opens for the chosen movie", (await bodyText()).includes("Your rating") && (await bodyText()).includes("Inception"));
const saveDisabled = await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.trim() === "Save").disabled);
check("Save is off until a rating is chosen", saveDisabled);
await page.click('button[aria-label="4.5 stars"]');
check("half star shows 4.5 / 5", (await bodyText()).includes("4.5 / 5"));
await typeInto("What did you think? (optional)", "Mind bending. The ending still bothers me.").catch(async () => { await page.type("textarea", "Mind bending. The ending still bothers me."); });
await page.screenshot({ path: "shots/82-rate-form.png" });
await clickText("Save"); 
await page.waitForFunction(() => location.pathname.startsWith("/movies/log"), { timeout: 10000 });
await sleep(900);
let t = await bodyText();
check("detail page shows title, year and opinion", t.includes("Inception") && t.includes("(2010)") && t.includes("Mind bending"));
check("detail page shows the rating", await page.$eval('[role="img"][aria-label="4.5 out of 5 stars"]', () => true).catch(() => false));
await page.screenshot({ path: "shots/83-movie-detail.png" });
const movies1 = await dbAll("movies");
check("movie saved once with its TMDB id", movies1.length === 1 && movies1[0].tmdbId === 27205);
check("poster copied into the journal as a data URL", typeof movies1[0].posterData === "string" && movies1[0].posterData.startsWith("data:image/png;base64,"), String(movies1[0].posterData).slice(0, 40));
check("fetchedAt recorded", typeof movies1[0].fetchedAt === "number");

// ---- 4. list and stats
await page.goto(BASE + "/movies/", { waitUntil: "networkidle0" }); await sleep(700);
t = await bodyText();
check("list shows the movie, rating, date and opinion", t.includes("Inception") && t.includes("Mind bending"));
check("stats line: 1 movie, average 4.5", t.includes("1 movie") && t.includes("4.5 of 5"), t.slice(0, 160));
await page.screenshot({ path: "shots/84-movies-list.png" });

// ---- 5. second viewing
await page.click("ul a"); await sleep(600);
await clickText("Log another viewing", "a"); await sleep(800);
check("rewatch form names the movie", (await bodyText()).includes("Log another viewing") && (await bodyText()).includes("Inception"));
await page.click('button[aria-label="5 stars"]');
await clickText("Save viewing");
await page.waitForFunction(() => location.pathname.startsWith("/movies/log"), { timeout: 8000 }); await sleep(800);
check("rewatch saved, other viewings listed", (await bodyText()).includes("Other viewings of this movie") && !(await bodyText()).includes("This is the only one"));
check("still one movie, two logs", (await dbAll("movies")).length === 1 && (await dbAll("movieLogs")).length === 2);

// ---- 6. manual movie
await page.goto(BASE + "/movies/add/", { waitUntil: "networkidle0" }); await sleep(700);
await clickText("Type the title myself"); await sleep(400);
const blocked = await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.trim() === "Save").disabled);
check("manual: Save is off without a title", blocked);
await typeInto("Movie title", "Home Video");
await typeInto("Year", "2019");
await page.click('button[aria-label="3 stars"]');
await clickText("Save");
await page.waitForFunction(() => location.pathname.startsWith("/movies/log"), { timeout: 8000 }); await sleep(700);
const m2 = (await dbAll("movies")).find((m) => m.tmdbId === null);
check("manual movie saved with no TMDB id", m2?.title === "Home Video" && m2?.year === 2019 && m2?.fetchedAt === null);
check("manual movie shows a placeholder poster", await page.evaluate(() => document.body.innerText.includes("Home Video") && !document.querySelector("article img")));

// ---- 7. edit
await clickText("Edit"); await sleep(400);
await page.click('button[aria-label="2 stars"]');
await clickText("Save changes"); await sleep(800);
check("edit saves the new rating", await page.$eval('[role="img"][aria-label="2 out of 5 stars"]', () => true).catch(() => false));
check("edit stamps 'Edited'", (await bodyText()).includes("Edited"));

// ---- 8. filter and sort
await page.goto(BASE + "/movies/", { waitUntil: "networkidle0" }); await sleep(700);
check("list now has 3 viewings", (await page.$$("ul li")).length >= 3);
await typeInto("Search your movies", "home"); await sleep(300);
let cards = await page.$$eval("ul li", (l) => l.map((x) => x.innerText));
check("filter narrows to the matching movie", cards.length === 1 && cards[0].includes("Home Video"), JSON.stringify(cards));
await typeInto("Search your movies", "zzz"); await sleep(300);
check("filter with no match says so", (await bodyText()).includes("No movie matches that"));
await typeInto("Search your movies", ""); await sleep(300);
await page.select('select[aria-label="Sort movies"]', "rating"); await sleep(300);
cards = await page.$$eval("ul li", (l) => l.map((x) => x.innerText));
check("sort by rating puts the 5 star viewing first", cards[0].includes("Inception"), cards[0]);
await page.select('select[aria-label="Sort movies"]', "title"); await sleep(300);
cards = await page.$$eval("ul li", (l) => l.map((x) => x.innerText));
check("sort by title is alphabetical", cards[0].includes("Home Video") && cards[1].includes("Inception"), JSON.stringify(cards));

// ---- 9. search errors
failSearch = 401;
await page.goto(BASE + "/movies/add/", { waitUntil: "networkidle0" }); await sleep(600);
await typeInto("Search for a movie", "matrix"); await sleep(1500);
check("a rejected key shows a clear message", (await bodyText()).includes("did not accept this key"));
failSearch = 429;
await typeInto("Search for a movie", "matrixx"); await sleep(1500);
check("rate limiting shows a wait message", (await bodyText()).includes("too many requests"));
failSearch = null;

// ---- 10. delete
await page.goto(BASE + "/movies/", { waitUntil: "networkidle0" }); await sleep(600);
await typeInto("Search your movies", "home"); await sleep(300);
await page.click("ul a"); await sleep(600);
await clickText("Delete"); await sleep(300);
check("delete warns that the movie goes too", (await bodyText()).includes("removes the movie from your list too"));
await page.evaluate(() => [...document.querySelectorAll('[role="dialog"] button')].find((x) => x.textContent.trim() === "Delete").click());
await page.waitForFunction(() => location.pathname === "/movies/" || location.pathname === "/movies", { timeout: 8000 }); await sleep(600);
check("deleting the only viewing removes the movie", (await dbAll("movies")).every((m) => m.title !== "Home Video"));

// ---- 11. backup round trip carries movies
await page.goto(BASE + "/backup/", { waitUntil: "networkidle0" }); await sleep(1200);
await clickText("Save a snapshot"); await sleep(700);
check("snapshot lists movie viewings", /movie logs?/.test(await bodyText()), (await bodyText()).slice(0, 400));
const snapLogs = (await dbAll("movieLogs")).length;
// wipe movies directly, then restore the snapshot through the UI
await idb(async (db) => new Promise((res) => { const tx = db.transaction(["movies", "movieLogs"], "readwrite"); tx.objectStore("movies").clear(); tx.objectStore("movieLogs").clear(); tx.oncomplete = () => res(true); }));
await page.reload({ waitUntil: "networkidle0" }); await sleep(1200);
await page.evaluate(() => { const li = [...document.querySelectorAll("li")].find((l) => l.textContent.includes("Saved by you")); [...li.querySelectorAll("button")].find((b) => b.textContent.trim() === "Restore").click(); });
await sleep(300);
await page.evaluate(() => [...document.querySelectorAll('[role="dialog"] button')].find((x) => x.textContent.trim() === "Restore").click());
await sleep(1200);
const restored = await dbAll("movies");
check("restore brings the movies back", restored.length === 1 && restored[0].title === "Inception");
check("restore brings the saved poster back", restored[0].posterData?.startsWith("data:image/png"));
check("restore brings the viewings back", (await dbAll("movieLogs")).length === snapLogs);

// ---- 12. offline: need the service worker in control first
await page.goto(BASE + "/movies/", { waitUntil: "networkidle0" });
await page.evaluate(() => navigator.serviceWorker.ready);
for (let i = 0; i < 40 && !(await page.evaluate(() => !!navigator.serviceWorker.controller)); i++) await sleep(250);
await page.setOfflineMode(true); offline = true;
await page.reload({ waitUntil: "networkidle0" }); await sleep(900);
check("OFFLINE: movies list loads", (await bodyText()).includes("Inception"));
const posterOk = await page.evaluate(async () => { const img = document.querySelector("ul li img"); if (!img) return "no img"; await img.decode().catch(() => {}); return img.naturalWidth > 0 ? "ok" : "broken"; });
check("OFFLINE: the saved poster still displays", posterOk === "ok", posterOk);
await page.goto(BASE + "/movies/add/", { waitUntil: "networkidle0" }); await sleep(700);
await typeInto("Search for a movie", "matrix"); await sleep(1500);
check("OFFLINE: search explains it cannot reach TMDB", (await bodyText()).includes("Could not reach TMDB"));
await clickText("Type the title myself"); await sleep(300);
await typeInto("Movie title", "Offline Watch");
await page.click('button[aria-label="3.5 stars"]');
await clickText("Save");
await page.waitForFunction(() => location.pathname.startsWith("/movies/log"), { timeout: 8000 }); await sleep(700);
check("OFFLINE: a manual movie can still be logged", (await bodyText()).includes("Offline Watch"));
await page.setOfflineMode(false); offline = false;

// ---- 13. phone size
await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
for (const [path, name] of [["/movies/", "90-mobile-movies"], ["/movies/add/", "91-mobile-add"], ["/settings/", "92-mobile-settings"]]) {
  await page.goto(BASE + path, { waitUntil: "networkidle0" }); await sleep(900);
  await page.screenshot({ path: `shots/${name}.png` });
  check(`no sideways scroll on phone: ${path}`, !(await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1)));
}
await page.goto(BASE + "/movies/", { waitUntil: "networkidle0" }); await sleep(600);
await page.click("ul a"); await sleep(700);
await page.screenshot({ path: "shots/93-mobile-detail.png" });
const tabs = await page.$$eval("nav a", (a) => a.filter((x) => x.offsetParent !== null).map((x) => x.innerText.replace(/\s+/g, " ").trim()).filter(Boolean));
check("phone tab bar has 5 tabs and no Backup", tabs.length === 5 && tabs.some((t) => t.includes("Movies")) && !tabs.some((t) => t.includes("Backup")), JSON.stringify(tabs));

await browser.close();
const real = errors.filter((e) => !/Failed to load resource|ERR_INTERNET_DISCONNECTED|net::ERR/.test(e));
console.log(real.length ? "CONSOLE ERRORS:\n" + [...new Set(real)].join("\n") : "no unexpected console errors");
console.log(failures === 0 ? "ALL PASSED" : failures + " FAILED");
