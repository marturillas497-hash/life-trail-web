import { launch, BASE, sleep } from "./lib.mjs";
const browser = await launch();
const errors = [];
const page = await browser.newPage();
page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
let failures = 0;
const check = (label, ok, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };
const clickText = (text, tag = "button") => page.evaluate((text, tag) => {
  const el = [...document.querySelectorAll(tag)].find((e) => e.textContent.trim() === text);
  if (!el) return false; el.click(); return true;
}, text, tag);
const bodyText = () => page.evaluate(() => document.body.innerText);
const overlayShown = () => page.evaluate(() => !!document.querySelector('[aria-label="App locked"]'));
const appInert = () => page.evaluate(() => document.querySelector(".h-dvh")?.inert === true);
const typeInto = async (label, text) => { const sel = `input[aria-label="${label}"]`; await page.waitForSelector(sel); await page.focus(sel); await page.$eval(sel, (el) => el.select()); await page.keyboard.type(text); };
const away = (ms = 50) => page.evaluate(async (ms) => {
  Object.defineProperty(document, "visibilityState", { value: "hidden", configurable: true });
  document.dispatchEvent(new Event("visibilitychange"));
  await new Promise((r) => setTimeout(r, ms));
  Object.defineProperty(document, "visibilityState", { value: "visible", configurable: true });
  document.dispatchEvent(new Event("visibilitychange"));
}, ms);
const idbClearLockout = () => page.evaluate(() => new Promise((resolve, reject) => {
  const open = indexedDB.open("life-trail-backups");
  open.onsuccess = () => {
    const db = open.result;
    const tx = db.transaction("settings", "readwrite");
    const store = tx.objectStore("settings");
    const get = store.get("appLock");
    get.onsuccess = () => { const row = get.result; row.value.lockedUntil = 0; row.value.failedAttempts = 0; store.put(row); };
    tx.oncomplete = () => { db.close(); resolve(true); };
    tx.onerror = () => reject(tx.error);
  };
}));

await page.setViewport({ width: 1280, height: 800 });
await page.goto(BASE + "/settings/", { waitUntil: "networkidle0" });
await sleep(800);
await page.screenshot({ path: "shots/60-settings.png", fullPage: true });
check("settings page shows install and app lock cards", (await bodyText()).includes("Install the app") && (await bodyText()).includes("App lock"));

// ---- set up
await clickText("Set up a PIN");
await typeInto("Choose a PIN (4 to 8 digits)", "4821");
await typeInto("Repeat the PIN", "4829");
await clickText("Continue");
check("mismatched PINs are rejected", (await bodyText()).includes("do not match"));
await typeInto("Repeat the PIN", "4821");
await clickText("Continue");
await page.waitForSelector('[data-testid="recovery-code"]');
const code = await page.$eval('[data-testid="recovery-code"]', (e) => e.textContent.trim());
check("recovery code shown (XXXX-XXXX-XXXX-XXXX)", /^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test(code), code);
const disabledBefore = await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.trim() === "Turn on app lock").disabled);
check("cannot finish before ticking 'I have saved this code'", disabledBefore);
await page.click('input[type="checkbox"]');
await clickText("Turn on app lock");
await sleep(800);
check("app lock is on, session stays unlocked", (await bodyText()).includes("App lock is on") && !(await overlayShown()));

// ---- lock now
await clickText("Lock now");
await sleep(400);
check("lock now shows the lock screen", await overlayShown());
check("app underneath is inert while locked", await appInert());
await page.screenshot({ path: "shots/61-locked.png" });
await typeInto("Enter your PIN", "0000");
await page.keyboard.press("Enter");
await sleep(900);
check("wrong PIN shows an error and stays locked", (await bodyText()).includes("not correct") && (await overlayShown()));
await typeInto("Enter your PIN", "4821");
await page.keyboard.press("Enter");
await sleep(900);
check("right PIN unlocks", !(await overlayShown()) && !(await appInert()));

// ---- reload starts locked
await page.reload({ waitUntil: "networkidle0" }); await sleep(900);
check("reload starts locked", await overlayShown());
await typeInto("Enter your PIN", "4821"); await page.keyboard.press("Enter"); await sleep(900);
check("unlock again after reload", !(await overlayShown()));

// ---- lockout after 5 wrong tries
await clickText("Lock now"); await sleep(300);
for (let i = 0; i < 5; i++) { await typeInto("Enter your PIN", "1111"); await page.keyboard.press("Enter"); await sleep(700); }
check("5 wrong tries trigger a lockout message", (await bodyText()).includes("Too many wrong tries"), (await bodyText()).slice(0, 200));
await typeInto("Enter your PIN", "4821"); await page.keyboard.press("Enter"); await sleep(700);
check("right PIN is refused during the lockout", (await overlayShown()) && (await bodyText()).includes("Too many wrong tries"));
await idbClearLockout();

// ---- forgot PIN with the recovery code (typed in lower case with spaces)
await clickText("Forgot your PIN?");
await typeInto("Recovery code", code.toLowerCase().replace(/-/g, " "));
await typeInto("New PIN", "7777");
await typeInto("Repeat new PIN", "7770");
await clickText("Set new PIN"); await sleep(500);
check("recovery: mismatched new PINs rejected", (await bodyText()).includes("do not match"));
await typeInto("Repeat new PIN", "7777");
await clickText("Set new PIN");
await page.waitForSelector('[data-testid="recovery-code"]', { timeout: 8000 });
const code2 = await page.$eval('[data-testid="recovery-code"]', (e) => e.textContent.trim());
check("recovery: a NEW recovery code is shown", /^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test(code2) && code2 !== code, code2);
await page.click('input[type="checkbox"]');
await clickText("Continue to my journal"); await sleep(600);
check("recovery: unlocked after setting the new PIN", !(await overlayShown()));
await clickText("Lock now").catch(() => {}); 
await page.goto(BASE + "/settings/", { waitUntil: "networkidle0" }); await sleep(700);
await typeInto("Enter your PIN", "4821"); await page.keyboard.press("Enter"); await sleep(800);
check("old PIN no longer works", await overlayShown());
await typeInto("Enter your PIN", "7777"); await page.keyboard.press("Enter"); await sleep(900);
check("new PIN works", !(await overlayShown()));

// ---- auto lock
await page.select("select", "0");
await sleep(400);
await away(50); await sleep(300);
check("auto-lock 'as soon as I leave': locks after being away", await overlayShown());
await typeInto("Enter your PIN", "7777"); await page.keyboard.press("Enter"); await sleep(800);
await page.select("select", "-1"); await sleep(300);
await away(50); await sleep(300);
check("auto-lock 'only when the app opens': stays unlocked", !(await overlayShown()));
await page.select("select", "60"); await sleep(300);
await away(50); await sleep(300);
check("auto-lock 1 minute: a quick glance away does not lock", !(await overlayShown()));

// ---- a draft survives locking
await page.select("select", "0"); await sleep(300);
await page.goto(BASE + "/journal/new/", { waitUntil: "networkidle0" }); await sleep(600);
// reload locked the app; unlock first
await typeInto("Enter your PIN", "7777"); await page.keyboard.press("Enter"); await sleep(800);
await typeInto("Title", "Half written thought");
await away(50); await sleep(300);
check("draft: locks while writing", await overlayShown());
await typeInto("Enter your PIN", "7777"); await page.keyboard.press("Enter"); await sleep(800);
check("draft: text is still there after unlocking", (await page.$eval('input[aria-label="Title"]', (e) => e.value)) === "Half written thought");

// ---- change PIN, new code, turn off
await page.goto(BASE + "/settings/", { waitUntil: "networkidle0" }); await sleep(600);
await typeInto("Enter your PIN", "7777"); await page.keyboard.press("Enter"); await sleep(800);
await clickText("Change PIN");
await typeInto("Current PIN", "7777"); await typeInto("New PIN", "2468"); await typeInto("Repeat the new PIN", "2468");
await clickText("Change PIN", "button"); await sleep(700);
const t = await bodyText();
check("change PIN works", t.includes("PIN changed"), t.slice(0, 300));

await clickText("Turn off");
await typeInto("Current PIN", "9999"); await clickText("Turn off", "button"); await sleep(600);
check("turn off refuses a wrong PIN", (await bodyText()).includes("not correct"));
await typeInto("Current PIN", "2468");
const submitOff = await page.evaluate(() => { const b = [...document.querySelectorAll("form button")].find((x) => x.textContent.trim() === "Turn off"); b.click(); return !!b; });
await sleep(800);
check("turn off works with the right PIN", (await bodyText()).includes("App lock is off") && (await bodyText()).includes("Set up a PIN"));

// ---- erase path
await clickText("Set up a PIN");
await typeInto("Choose a PIN (4 to 8 digits)", "1357"); await typeInto("Repeat the PIN", "1357");
await clickText("Continue"); await page.waitForSelector('[data-testid="recovery-code"]');
await page.click('input[type="checkbox"]'); await clickText("Turn on app lock"); await sleep(700);
// put some data in first
await page.goto(BASE + "/journal/new/", { waitUntil: "networkidle0" }); await sleep(600);
await typeInto("Enter your PIN", "1357"); await page.keyboard.press("Enter"); await sleep(800);
const chips = await page.$$("button[aria-pressed]"); await chips[0].click();
await page.type('textarea[aria-label="Entry text"]', "Something to be erased.");
await page.keyboard.down("Control"); await page.keyboard.press("s"); await page.keyboard.up("Control");
await page.waitForFunction(() => location.pathname.startsWith("/journal/entry"), { timeout: 8000 });
await page.reload({ waitUntil: "networkidle0" }); await sleep(800);
check("erase path: locked with data present", await overlayShown());
await clickText("Forgot your PIN?");
await clickText("I do not have my recovery code");
const eraseDisabled = await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.trim() === "Erase everything").disabled);
check("erase button disabled until ERASE is typed", eraseDisabled);
await typeInto("Type ERASE to confirm", "erase");
check("erase is case sensitive", await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.trim() === "Erase everything").disabled));
await typeInto("Type ERASE to confirm", "ERASE");
await clickText("Erase everything"); await sleep(1500);
check("erase: overlay gone, lock removed", !(await overlayShown()));
await page.goto(BASE + "/journal/", { waitUntil: "networkidle0" }); await sleep(900);
check("erase: journal is empty", (await bodyText()).includes("No entries yet"));
await page.goto(BASE + "/tags/", { waitUntil: "networkidle0" }); await sleep(700);
check("erase: default tags are back", (await bodyText()).includes("Grateful"));

await browser.close();
console.log(errors.length ? "CONSOLE ERRORS:\n" + [...new Set(errors)].join("\n") : "no console errors");
console.log(failures === 0 ? "ALL PASSED" : failures + " FAILED");
