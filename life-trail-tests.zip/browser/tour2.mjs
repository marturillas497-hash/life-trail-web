import { launch, BASE, sleep } from "./lib.mjs";
const browser = await launch();
const errors = [];
const page = await browser.newPage();
page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
let failures = 0;
const check = (label, ok, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : extra); if (!ok) failures++; };

const clickText = (text, tag = "button") => page.evaluate((text, tag) => {
  const el = [...document.querySelectorAll(tag)].find((e) => e.textContent.trim() === text);
  if (!el) return false; el.click(); return true;
}, text, tag);
const bodyText = () => page.evaluate(() => document.body.innerText);

await page.setViewport({ width: 1280, height: 800 });

// ---- create an entry
await page.goto(BASE + "/journal/new", { waitUntil: "networkidle0" });
await page.waitForSelector('input[aria-label="Title"]');
await sleep(400);
const chips = await page.$$("button[aria-pressed]");
await chips[0].click(); await chips[4].click();
await page.type('input[aria-label="Title"]', "Coffee with a friend");
await page.type('textarea[aria-label="Entry text"]', "Long chat, felt really loved.");
await page.keyboard.down("Control"); await page.keyboard.press("s"); await page.keyboard.up("Control");
await page.waitForFunction(() => /^\/journal\/entry\/?$/.test(location.pathname), { timeout: 8000 });
check("entry created and opened", true);

// ---- write an entry for a past day from the calendar
await page.goto(BASE + "/calendar", { waitUntil: "networkidle0" });
await sleep(800);
await page.screenshot({ path: "shots/10-calendar-desktop.png" });
const cellLabel = await page.evaluate(() => {
  const cells = [...document.querySelectorAll('button[aria-pressed][aria-label*=","]')];
  const first = cells.find((c) => c.getAttribute("aria-label").includes("0 entries"));
  first.click(); return first.getAttribute("aria-label");
});
await sleep(300);
const hasWriteBtn = await clickText("Write an entry for this day", "a");
check("past day offers a write button (" + cellLabel + ")", hasWriteBtn);
await page.waitForSelector('input[aria-label="Title"]');
check("form shows the chosen past date", (await bodyText()).includes(cellLabel.split(",").slice(0, 3).join(",")), await bodyText());
await sleep(300);
const chips2 = await page.$$("button[aria-pressed]");
await chips2[8].click();
await page.type('textarea[aria-label="Entry text"]', "A tired day.");
await page.click('button[title="Save (Ctrl+S)"]');
await page.waitForFunction(() => /^\/journal\/entry\/?$/.test(location.pathname), { timeout: 8000 });
check("past-day entry saved", true);

// ---- tags: create with the emoji picker
await page.goto(BASE + "/tags", { waitUntil: "networkidle0" });
await sleep(500);
await clickText("New tag");
await page.waitForSelector('input[aria-label="Tag name"]');
await sleep(1500); // picker lazy-loads
await page.screenshot({ path: "shots/11-tag-dialog.png" });
const pickerEmoji = await page.evaluate(() => {
  const btn = document.querySelector('button[aria-label="grinning"], button[data-unified="1f600"]') ||
    document.querySelector(".epr-emoji-category button.epr-emoji, button.epr-emoji");
  if (btn) { btn.click(); return btn.getAttribute("data-unified") || btn.getAttribute("aria-label") || "clicked"; }
  return null;
});
check("emoji picker rendered and an emoji was picked", !!pickerEmoji, String(pickerEmoji));
await page.type('input[aria-label="Tag name"]', "Curious");
await clickText("Save");
await sleep(700);
check("new tag listed", (await bodyText()).includes("Curious"));
await page.screenshot({ path: "shots/12-tags.png" });

// duplicate tag rejected
await clickText("New tag");
await page.waitForSelector('input[aria-label="Tag name"]');
await sleep(800);
await page.evaluate(() => document.querySelector('button[aria-label="Choose emoji"]'));
await page.type('input[aria-label="Tag name"]', "happy");
await page.evaluate(() => { const b = document.querySelector("button.epr-emoji"); if (b) b.click(); });
await clickText("Save");
await sleep(500);
check("duplicate tag name is rejected", (await bodyText()).includes("already exists"));
await clickText("Cancel");

// ---- backup page
await page.goto(BASE + "/backup", { waitUntil: "networkidle0" });
await sleep(1500);
const t1 = await bodyText();
check("backup status shows 2 entries", t1.includes("2 entries"), t1.slice(0, 300));
check("an automatic snapshot exists", /Automatic, 2 entries/.test(t1), t1);
await page.screenshot({ path: "shots/13-backup-desktop.png", fullPage: true });
await clickText("Save a snapshot");
await sleep(600);
check("manual snapshot appears", (await bodyText()).includes("Saved by you"));

// ---- delete an entry, then restore the snapshot
await page.goto(BASE + "/journal", { waitUntil: "networkidle0" });
await sleep(500);
await page.click('ul a');
await page.waitForSelector("article");
await clickText("Delete");
await sleep(300);
await page.evaluate(() => { const b = [...document.querySelectorAll('[role="dialog"] button')].find((x) => x.textContent.trim() === "Delete"); b.click(); });
await sleep(800);
const afterDelete = await page.evaluate(() => document.querySelectorAll("section ul > li").length);
check("entry deleted (1 left)", afterDelete === 1, String(afterDelete));

await page.goto(BASE + "/backup", { waitUntil: "networkidle0" });
await sleep(800);
// restore the 'Saved by you' snapshot (2 entries)
await page.evaluate(() => {
  const li = [...document.querySelectorAll("li")].find((l) => l.textContent.includes("Saved by you"));
  [...li.querySelectorAll("button")].find((b) => b.textContent.trim() === "Restore").click();
});
await sleep(300);
await page.evaluate(() => { const b = [...document.querySelectorAll('[role="dialog"] button')].find((x) => x.textContent.trim() === "Restore"); b.click(); });
await sleep(1000);
const t2 = await bodyText();
check("restore confirmation shown", t2.includes("Restored the snapshot"), t2.slice(0, 400));
check("a Before-a-restore snapshot was saved", t2.includes("Before a restore"));
await page.goto(BASE + "/journal", { waitUntil: "networkidle0" });
await sleep(500);
const afterRestore = await page.evaluate(() => document.querySelectorAll("section ul > li").length);
check("entry is back after restore (2 entries)", afterRestore === 2, String(afterRestore));

// ---- phone size
await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
for (const [path, name] of [["/journal", "20-mobile-list"], ["/calendar", "21-mobile-calendar"], ["/backup", "22-mobile-backup"], ["/tags", "23-mobile-tags"]]) {
  await page.goto(BASE + path, { waitUntil: "networkidle0" });
  await sleep(900);
  await page.screenshot({ path: `shots/${name}.png` });
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
  check(`no sideways scroll on phone: ${path}`, !overflow);
}
await page.goto(BASE + "/journal", { waitUntil: "networkidle0" });
await page.click("ul a"); await sleep(600);
await page.screenshot({ path: "shots/24-mobile-detail.png" });

// ---- dark mode
await page.emulateMediaFeatures([{ name: "prefers-color-scheme", value: "dark" }]);
await page.setViewport({ width: 1280, height: 800 });
await page.goto(BASE + "/journal", { waitUntil: "networkidle0" }); await sleep(600);
await page.screenshot({ path: "shots/30-dark-desktop.png" });

await browser.close();
console.log(errors.length ? "CONSOLE ERRORS:\n" + errors.join("\n") : "no console errors");
console.log(failures === 0 ? "ALL PASSED" : failures + " FAILED");
