import { launch, BASE, sleep } from "./lib.mjs";
const browser = await launch();
const page = await browser.newPage();
await page.setViewport({ width: 390, height: 844, isMobile: true });
await page.goto(BASE + "/movies/", { waitUntil: "networkidle0" }); await sleep(1200);
const r = await page.evaluate(() => { const img = document.querySelector('img[alt="TMDB"]'); return img ? { present: true, ok: img.complete && img.naturalWidth > 0 } : { present: false }; });
console.log(JSON.stringify(r));
await page.screenshot({ path: "shots/95-logo-check.png" });
await browser.close();
