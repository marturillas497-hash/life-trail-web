import puppeteer from "puppeteer-core";
import fs from "node:fs";

const BASE = "http://localhost:3300";
let failures = 0;
const check = (label, ok, extra = "") => { console.log(ok ? "ok  " : "FAIL", label, ok ? "" : String(extra)); if (!ok) failures++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await puppeteer.launch({ executablePath: "/opt/google/chrome/chrome", headless: "new", args: ["--no-sandbox", "--disable-gpu"] });
const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 900 });
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => { if (m.type() === "error" && !/net::ERR|Failed to load resource/.test(m.text())) errors.push(m.text()); });
await page.evaluateOnNewDocument(() => { window.__opened = []; window.open = (url) => { window.__opened.push(String(url)); return null; }; });
const ctrl = async (key) => { await page.keyboard.down("Control"); await page.keyboard.press(key); await page.keyboard.up("Control"); };
const idb = (fn, arg) => page.evaluate(`(${fn.toString()})(${JSON.stringify(arg ?? null)})`);

// ---------- Ctrl+Enter saves a new entry ----------
await page.goto(`${BASE}/journal/new/`, { waitUntil: "networkidle0" });
await page.waitForSelector(".cm-content");
await (await page.$$("button[aria-pressed]"))[0].click();
await page.click(".cm-content");
await page.keyboard.type("Plain words only");
await ctrl("Enter");
await page.waitForFunction(() => location.pathname.includes("/journal/entry"), { timeout: 8000 }).catch(() => {});
check("Ctrl+Enter saves a new entry", page.url().includes("/journal/entry"), page.url());
await sleep(800);
const savedBody = await page.evaluate(() => document.querySelector(".lt-md-view .cm-content")?.innerText);
check("saving did not add a blank line", savedBody === "Plain words only", JSON.stringify(savedBody));

// ---------- Ctrl+Enter on a link opens it and does not save ----------
await page.goto(`${BASE}/journal/new/`, { waitUntil: "networkidle0" });
await page.waitForSelector(".cm-content");
await (await page.$$("button[aria-pressed]"))[0].click();
await page.click(".cm-content");
await page.keyboard.type("go [here](https://example.com/x) ok");
await page.click("input[aria-label=Title]");
await page.click(".cm-link");
await ctrl("Enter");
await sleep(400);
const opened = await page.evaluate(() => window.__opened);
check("Ctrl+Enter on a link opens it", opened.at(-1) === "https://example.com/x", JSON.stringify(opened));
check("...and does not save", page.url().includes("/journal/new"), page.url());

// ---------- reading view toggle ----------
await page.click(".cm-content");
await page.keyboard.down("Control"); await page.keyboard.press("End"); await page.keyboard.up("Control");
await page.keyboard.type(" **loud**");
await page.click("[data-testid=reading-toggle]");
await sleep(300);
let st = await page.evaluate(() => ({
  editable: document.querySelector(".cm-content").getAttribute("contenteditable"),
  boldDisabled: document.querySelector("button[aria-label^='Bold']").disabled,
  text: document.querySelector(".cm-content").innerText,
  btn: document.querySelector("[data-testid=reading-toggle]").textContent,
}));
check("reading view is not editable", st.editable === "false", JSON.stringify(st));
check("toolbar is disabled while reading", st.boldDisabled);
check("reading view hides the symbols", !st.text.includes("**") && !st.text.includes("](") && st.text.includes("loud"), st.text);
check("button now says Edit", st.btn.includes("Edit"), st.btn);
await page.click(".cm-link");
const op2 = await page.evaluate(() => window.__opened);
check("plain click opens links while reading", op2.length === 2, JSON.stringify(op2));
await ctrl("e");
await sleep(300);
st = await page.evaluate(() => ({ editable: document.querySelector(".cm-content").getAttribute("contenteditable"), btn: document.querySelector("[data-testid=reading-toggle]").textContent }));
check("Ctrl+E goes back to editing", st.editable === "true" && st.btn.includes("Read"), JSON.stringify(st));
await page.click(".cm-content");
await page.keyboard.type("!");
const txt = await page.evaluate(() => document.querySelector(".cm-content").textContent);
check("typing works again after reading", txt.includes("!"), txt);
// leave this draft: save it so later pages have two entries
await ctrl("Enter");
await page.waitForFunction(() => location.pathname.includes("/journal/entry"), { timeout: 8000 }).catch(() => {});
await sleep(500);

// ---------- Ctrl+Enter saves edits ----------
const id = new URL(page.url()).searchParams.get("id");
await page.goto(`${BASE}/journal/entry/edit/?id=${id}`, { waitUntil: "networkidle0" });
await page.waitForSelector(".cm-content");
await page.click(".cm-content");
await page.keyboard.down("Control"); await page.keyboard.press("End"); await page.keyboard.up("Control");
await page.keyboard.type(" EDITED");
await ctrl("Enter");
await page.waitForFunction(() => !location.pathname.includes("/edit"), { timeout: 8000 }).catch(() => {});
await sleep(800);
const edited = await page.evaluate(() => document.querySelector(".lt-md-view .cm-content")?.innerText);
check("Ctrl+Enter saves edits", edited?.includes("EDITED"), edited);

// ---------- seed movies and more entries ----------
const poster = "data:image/png;base64," + fs.readFileSync("/tmp/bt/poster.png").toString("base64");
await page.goto(`${BASE}/movies/`, { waitUntil: "networkidle0" });
await idb(async (poster) => {
  const open = () => new Promise((res) => { const r = indexedDB.open("life-trail"); r.onsuccess = () => res(r.result); });
  const db = await open();
  const put = (store, row) => new Promise((res, rej) => { const tx = db.transaction(store, "readwrite"); const q = tx.objectStore(store).add(row); q.onsuccess = () => res(q.result); tx.onerror = () => rej(tx.error); });
  const movieId = await put("movies", { tmdbId: null, title: "Test Film", year: 2020, overview: "", posterPath: null, posterData: poster, createdAt: Date.now(), fetchedAt: null });
  const today = new Date(); const key = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  await put("movieLogs", { movieId, rating: 4, opinion: "Very good film with a long opinion ".repeat(6), watchedDate: key(today), createdAt: Date.now(), updatedAt: Date.now() });
  const noPoster = await put("movies", { tmdbId: null, title: "Posterless", year: null, overview: "", posterPath: null, posterData: null, createdAt: Date.now(), fetchedAt: null });
  await put("movieLogs", { movieId: noPoster, rating: 3, opinion: "", watchedDate: "2026-01-05", createdAt: Date.now(), updatedAt: Date.now() });
  return true;
}, poster);
await page.reload({ waitUntil: "networkidle0" });
await sleep(500);
const posterButtons = await page.$$("button[aria-label^='Enlarge poster']");
check("poster has an enlarge button", posterButtons.length === 1, posterButtons.length);
await posterButtons[0].click();
await sleep(400);
let lb = await page.evaluate(() => ({ dialog: !!document.querySelector("[role=dialog]"), img: document.querySelector("[role=dialog] img")?.getBoundingClientRect().height, url: location.pathname }));
check("pressing the poster opens the viewer, not the page", lb.dialog && lb.url.includes("/movies") && !lb.url.includes("log") && lb.img > 300, JSON.stringify(lb));
await page.screenshot({ path: "/tmp/bt/shots/lightbox.png" });
await page.keyboard.press("Escape");
await sleep(300);
check("Escape closes the viewer", !(await page.$("[role=dialog]")));
await posterButtons[0].click(); await sleep(300);
await page.mouse.click(30, 450); await sleep(300);
check("clicking outside closes the viewer", !(await page.$("[role=dialog]")));
await page.click("a[aria-label='Test Film, open details']", { offset: { x: 230, y: 100 } }).catch(() => {});
await page.waitForFunction(() => location.pathname.includes("/movies/log"), { timeout: 5000 }).catch(() => {});
check("pressing the rest of the card opens the viewing", page.url().includes("/movies/log"), page.url());
const backBtn = await page.evaluate(() => { const a = [...document.querySelectorAll("a")].find((x) => x.textContent.trim() === "Movies/Shows" && x.closest("article")); return a ? { border: getComputedStyle(a).borderTopWidth, radius: getComputedStyle(a).borderTopLeftRadius, svg: !!a.querySelector("svg") } : null; });
check("back link looks like a button", backBtn && backBtn.border === "1px" && backBtn.svg, JSON.stringify(backBtn));
await sleep(800);
await sleep(800);
const enlargeOnDetail = await page.$("button[aria-label^='Enlarge poster']");
check("poster on the viewing page enlarges too", !!enlargeOnDetail);
await page.screenshot({ path: "/tmp/bt/shots/movie-detail.png" });
// edit viewing, Ctrl+Enter saves
await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.trim() === "Edit").click());
await sleep(300);
await page.click("textarea");
await page.keyboard.type(" EXTRA");
await ctrl("Enter");
await sleep(800);
const detailText = await page.evaluate(() => document.querySelector("article").innerText);
check("Ctrl+Enter saves a viewing", detailText.includes("EXTRA"), detailText.slice(0, 200));

// movie list cards are the same size and filter works
await page.goto(`${BASE}/movies/`, { waitUntil: "networkidle0" });
await sleep(400);
const sizes = await page.evaluate(() => [...document.querySelectorAll("ul > li")].map((l) => Math.round(l.getBoundingClientRect().height)));
check("movie cards share one height", new Set(sizes).size === 1 && sizes.length === 2, JSON.stringify(sizes));

// entries for insights
await idb(async () => {
  const open = () => new Promise((res) => { const r = indexedDB.open("life-trail"); r.onsuccess = () => res(r.result); });
  const db = await open();
  const tags = await new Promise((res) => { const q = db.transaction("tags").objectStore("tags").getAll(); q.onsuccess = () => res(q.result); });
  const add = (row) => new Promise((res) => { const tx = db.transaction("entries", "readwrite"); tx.objectStore("entries").add(row); tx.oncomplete = res; });
  const key = (y, m, d) => `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  const plan = [
    [2026, 11, 1, [0]], [2026, 11, 2, [0]], [2026, 11, 3, [1]], [2026, 11, 4, [0, 2]], [2026, 11, 5, [2]], [2026, 11, 6, [0]], [2026, 11, 9, [1]], [2026, 11, 10, [0]],
    [2026, 10, 3, [1]], [2026, 10, 4, [1]], [2026, 10, 5, [0]], [2026, 10, 12, [2]],
  ];
  for (const [y, m, d, ix] of plan) await add({ date: key(y, m, d), title: "", body: "seed", tagIds: ix.map((i) => tags[i].id), createdAt: Date.UTC(y, m - 1, d, 12), updatedAt: Date.UTC(y, m - 1, d, 12) });
  return true;
});
await page.goto(`${BASE}/insights/`, { waitUntil: "networkidle0" });
await sleep(900);
const ins = await page.evaluate(() => ({
  text: document.querySelector("main").innerText,
  cal: document.querySelectorAll("section")[0] && [...document.querySelectorAll("h2")].map((h) => h.textContent),
  segments: document.querySelectorAll("[aria-label='Share of each feeling'] > div > div").length,
  cells: [...document.querySelectorAll("h2")].find((h) => h.textContent === "Mood calendar")?.parentElement.querySelectorAll("div[title]").length,
}));
console.log(JSON.stringify(ins.cal));
check("old Emotions block is gone", !ins.cal.includes("Emotions"));
check("insights has the new cards", ["Mood calendar", "How you felt", "Days of the week"].every((t) => ins.cal.includes(t)), JSON.stringify(ins.cal));
check("share bar has one segment per feeling", ins.segments >= 2, ins.segments);
check("mood calendar shows the month's days", ins.cells >= 28, ins.cells);
check("change vs previous month is shown", /Change compared with October 2026/.test(ins.text), ins.text.slice(0, 600));
const pcts = await page.evaluate(() => [...document.querySelectorAll("h2")].find((h) => h.textContent === "How you felt").parentElement.querySelectorAll("li span.font-medium")).then ? [] : [];
const shareText = await page.evaluate(() => [...document.querySelectorAll("section")].find((s) => s.querySelector("h2")?.textContent === "How you felt").innerText);
const pctNums = [...shareText.matchAll(/(\d+)%/g)].map((m) => Number(m[1])).slice(1);
const sum = pctNums.reduce((a, b) => a + b, 0);
check("feeling shares add up to about 100%", sum >= 98 && sum <= 102, `${sum} from ${pctNums}`);
check("top feeling is not simply 100%", Math.max(...pctNums) < 100, pctNums.join());
await page.screenshot({ path: "/tmp/bt/shots/insights.png", fullPage: true });
await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent === "All time").click());
await sleep(500);
const allText = await page.evaluate(() => document.querySelector("main").innerText);
check("all time view has no comparison line", !/Change compared with/.test(allText));

// ---------- guide ----------
await page.goto(`${BASE}/journal/`, { waitUntil: "networkidle0" });
await page.click("aside a[href='/guide/']");
await page.waitForFunction(() => location.pathname.includes("/guide"), { timeout: 5000 }).catch(() => {});
await sleep(500);
const guide = await page.evaluate(() => ({ h1: document.querySelector("h1")?.textContent, h2: [...document.querySelectorAll("h2")].map((h) => h.textContent).length, back: !!document.querySelector("article a svg"), active: document.querySelector("aside a[href='/guide/']").getAttribute("aria-current") }));
check("How to use button opens the guide", guide.h1 === "How to use Life Trail" && guide.h2 >= 9 && guide.back && guide.active === "page", JSON.stringify(guide));
await page.screenshot({ path: "/tmp/bt/shots/guide.png" });
check("no page errors", errors.length === 0, errors.join("\n"));
await browser.close();
console.log(failures === 0 ? "\nALL PASSED" : `\n${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
